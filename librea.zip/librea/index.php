<?php
require __DIR__ . '/app/bootstrap.php';

// ---- Proses form: index.php?do=cart ----
if (isset($_GET['do'])) {
    if (!in_array($_GET['do'], ACTIONS, true)) { http_response_code(404); exit('Aksi tidak ditemukan'); }
    require ROOT . '/actions/' . $_GET['do'] . '.php';
    exit;
}

// ---- Halaman: index.php?page=cart ----
$current = $_GET['page'] ?? 'home';
if (!in_array($current, PAGES, true)) { http_response_code(404); exit('Halaman tidak ditemukan'); }
require ROOT . "/pages/$current.php";