<?php
session_start();

const BASE    = '/librea';          // nama folder di htdocs
const PAGES   = ['home', 'book', 'about', 'contact', 'login', 'register',
                 'cart', 'checkout', 'payment', 'success', 'profile'];
const ACTIONS = ['cart', 'wishlist', 'review', 'logout', 'cancel'];
define('ROOT', dirname(__DIR__));

foreach (['db', 'helpers', 'auth', 'upload', 'icons', 'components', 'cancel'] as $file) {
    require __DIR__ . "/$file.php";
}