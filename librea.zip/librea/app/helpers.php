<?php
// ---------- Format ----------
function e($s)  { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function rp($n) { return 'Rp' . number_format((float)$n, 0, ',', '.'); }

// ---------- URL ----------
function url($path = '')           { return BASE . '/' . ltrim($path, '/'); }
function route($page, $p = [])     { return url('index.php?' . http_build_query(['page' => $page] + $p)); }
function action($name)             { return url('index.php?do=' . $name); }
function admin_url($page, $p = []) { return url('admin/index.php?' . http_build_query(['page' => $page] + $p)); }

// ---------- Redirect ----------
function redirect($to)             { header('Location: ' . $to); exit; }
function go($page, $p = [])        { redirect(route($page, $p)); }
function admin_go($page, $p = [])  { redirect(admin_url($page, $p)); }

// Kembali ke halaman asal: tempatkan back_input() di dalam <form>, lalu panggil go_back() di action.
function back_input() {
    return '<input type="hidden" name="back" value="' . e($_SERVER['QUERY_STRING'] ?? '') . '">';
}
function go_back($default = 'home') {
    parse_str($_POST['back'] ?? '', $q);
    $page = $q['page'] ?? $default;
    unset($q['page']);
    go(in_array($page, PAGES, true) ? $page : $default, $q);
}

// ---------- Pesan singkat (toast) ----------
function flash($msg = null) {
    if ($msg !== null) { $_SESSION['flash'] = $msg; return; }
    $f = $_SESSION['flash'] ?? '';
    unset($_SESSION['flash']);
    return $f;
}