<?php
// ---------- Pengaturan database (sesuaikan dengan XAMPP-mu) ----------
const DB_HOST = '127.0.0.1';
const DB_PORT = 8111;          // port MySQL di XAMPP Control Panel (bawaan: 3306)
const DB_NAME = 'librea';
const DB_USER = 'root';
const DB_PASS = '';

$pdo = new PDO(
    'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
    DB_USER,
    DB_PASS,
    [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
);

function q($sql, $args = [])    { global $pdo; $st = $pdo->prepare($sql); $st->execute($args); return $st; }
function rows($sql, $args = []) { return q($sql, $args)->fetchAll(); }   // banyak baris
function row($sql, $args = [])  { return q($sql, $args)->fetch(); }      // satu baris
function val($sql, $args = [])  { return q($sql, $args)->fetchColumn(); }// satu nilai