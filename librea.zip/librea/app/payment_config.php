<?php
// ==========================================================================
// Pengaturan pembayaran toko — GANTI dengan data asli
// ==========================================================================

// Ongkos kirim per pesanan (Rupiah)
const SHIPPING_FEE = 10000;

// Rekening bank & nomor e-wallet milik toko (tujuan pembayaran dari pembeli)
//   'no' = nomor rekening / nomor e-wallet     'an' = atas nama
function pay_accounts() {
    return [
        'bank' => [
            'bca'     => ['no' => '1234567890',  'an' => 'Toko Buku Libréa'],
            'mandiri' => ['no' => '1230001234567', 'an' => 'Toko Buku Libréa'],
            'permata' => ['no' => '9876543210',  'an' => 'Toko Buku Libréa'],
            'bri'     => ['no' => '012345678901234', 'an' => 'Toko Buku Libréa'],
            'bni'     => ['no' => '0123456789',  'an' => 'Toko Buku Libréa'],
        ],
        'ewallet' => [
            'gopay'   => ['no' => '081234567890', 'an' => 'Toko Buku Libréa'],
            'dana'    => ['no' => '081234567891', 'an' => 'Toko Buku Libréa'],
            'ovo'     => ['no' => '081234567892', 'an' => 'Toko Buku Libréa'],
        ],
    ];
}