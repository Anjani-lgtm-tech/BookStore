<?php
// ==========================================================================
// upload.php — unggah gambar
// Format: JPG, PNG, GIF, WEBP, BMP, AVIF, ICO, SVG (khusus sampul buku),
//         HEIC/TIFF (hanya jika ekstensi Imagick tersedia).
// ==========================================================================

// Pesan error terakhir dari save_image() ('' jika tidak ada)
function image_error($set = null) {
    static $err = '';
    if ($set !== null) $err = $set;
    return $err;
}

// Kenali jenis file dari ISINYA (bukan dari nama / ekstensi).
function detect_image_type($tmp) {
    $head = (string)@file_get_contents($tmp, false, null, 0, 4096);

    if (strlen($head) > 12 && substr($head, 4, 4) === 'ftyp') {            // keluarga HEIF / AVIF
        $brand = substr($head, 8, 4);
        if (in_array($brand, ['avif', 'avis'], true)) return 'avif';
        if (in_array($brand, ['heic', 'heix', 'hevc', 'hevx', 'heim', 'heis', 'mif1', 'msf1'], true)) return 'heic';
    }
    if (stripos($head, '<svg') !== false) return 'svg';

    $mime = '';
    if (function_exists('finfo_open')) {
        $fi   = finfo_open(FILEINFO_MIME_TYPE);
        $mime = (string)finfo_file($fi, $tmp);
        finfo_close($fi);
    }
    if ($mime === '' && ($i = @getimagesize($tmp))) $mime = $i['mime'];

    $map = [
        'image/jpeg' => 'jpg',  'image/jpg' => 'jpg',  'image/pjpeg' => 'jpg',
        'image/png'  => 'png',  'image/x-png' => 'png',
        'image/gif'  => 'gif',  'image/webp' => 'webp',
        'image/bmp'  => 'bmp',  'image/x-ms-bmp' => 'bmp',
        'image/avif' => 'avif', 'image/tiff' => 'tiff',
        'image/heic' => 'heic', 'image/heif' => 'heic',
        'image/svg+xml' => 'svg',
        'image/x-icon' => 'ico', 'image/vnd.microsoft.icon' => 'ico',
    ];
    return $map[$mime] ?? null;
}

// Bersihkan SVG dari skrip berbahaya.
function clean_svg($svg) {
    $svg = preg_replace('#<script\b.*?</script>#is', '', $svg);
    $svg = preg_replace('#<foreignObject\b.*?</foreignObject>#is', '', $svg);
    $svg = preg_replace('/\son\w+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $svg);
    $svg = preg_replace('/(xlink:href|href)\s*=\s*("|\')\s*javascript:[^"\']*\2/i', '', $svg);
    return $svg;
}

// Muat gambar ke GD (null jika tidak didukung server).
function gd_load($tmp, $type) {
    $fn = [
        'jpg' => 'imagecreatefromjpeg', 'png' => 'imagecreatefrompng', 'webp' => 'imagecreatefromwebp',
        'bmp' => 'imagecreatefrombmp',  'avif' => 'imagecreatefromavif', 'gif' => 'imagecreatefromgif',
    ][$type] ?? null;
    return ($fn && function_exists($fn)) ? @$fn($tmp) : null;
}

// Putar gambar sesuai info rotasi kamera HP (EXIF).
function gd_orient($tmp, $img) {
    if (!function_exists('exif_read_data') || !function_exists('imagerotate')) return $img;
    $ex  = @exif_read_data($tmp);
    $deg = [3 => 180, 6 => -90, 8 => 90][(int)($ex['Orientation'] ?? 1)] ?? 0;
    return $deg ? imagerotate($img, $deg, 0) : $img;
}

// HEIC / TIFF → JPG memakai Imagick (jika ada).
function imagick_to_jpg($tmp, $dest, $max) {
    if (!class_exists('Imagick')) return false;
    try {
        $im = new Imagick();
        $im->readImage($tmp . '[0]');
        if (method_exists($im, 'autoOrient')) $im->autoOrient();
        $im->setImageBackgroundColor('white');
        $im = $im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
        if (max($im->getImageWidth(), $im->getImageHeight()) > $max) $im->thumbnailImage($max, $max, true);
        $im->setImageFormat('jpeg');
        $im->setImageCompressionQuality(88);
        $im->stripImage();
        $ok = $im->writeImage($dest);
        $im->clear();
        return $ok;
    } catch (Throwable $e) {
        return false;
    }
}

// ---------- FUNGSI UTAMA ----------
// Mengembalikan nama file, atau null.
// null + image_error() === ''  → tidak ada file dipilih (bukan kesalahan)
// null + image_error() !== ''  → ada file tapi gagal; isi pesan alasannya
function save_image($field, $folder, $max = 1600) {
    image_error('');

    $f = $_FILES[$field] ?? null;
    if (!$f || $f['error'] === UPLOAD_ERR_NO_FILE) return null;

    $upErr = [
        UPLOAD_ERR_INI_SIZE   => 'Ukuran file melebihi batas server (upload_max_filesize di php.ini).',
        UPLOAD_ERR_FORM_SIZE  => 'Ukuran file terlalu besar.',
        UPLOAD_ERR_PARTIAL    => 'Unggahan terputus. Coba lagi.',
        UPLOAD_ERR_NO_TMP_DIR => 'Folder sementara server tidak ditemukan.',
        UPLOAD_ERR_CANT_WRITE => 'Server gagal menyimpan file.',
    ];
    if ($f['error'] !== UPLOAD_ERR_OK) { image_error($upErr[$f['error']] ?? 'Unggahan gagal.'); return null; }
    if ($f['size'] > 20 * 1024 * 1024) { image_error('Ukuran file terlalu besar (maks. 20 MB).'); return null; }

    $tmp  = $f['tmp_name'];
    $type = detect_image_type($tmp);
    if (!$type) { image_error('File ini bukan gambar yang dikenali. Gunakan JPG, PNG, WEBP, GIF, BMP, atau AVIF.'); return null; }
    if ($type === 'svg' && $folder !== 'books') { image_error('Format SVG hanya boleh untuk sampul buku.'); return null; }

    $dir = ROOT . "/uploads/$folder";
    if (!is_dir($dir) && !mkdir($dir, 0777, true)) { image_error('Folder uploads tidak bisa dibuat.'); return null; }

    $name = uniqid();

    // --- SVG: bersihkan lalu simpan ---
    if ($type === 'svg') {
        file_put_contents("$dir/$name.svg", clean_svg((string)file_get_contents($tmp)));
        return "$name.svg";
    }

    // --- GIF / AVIF / ICO: simpan apa adanya ---
    if (in_array($type, ['gif', 'avif', 'ico'], true)) {
        move_uploaded_file($tmp, "$dir/$name.$type");
        return "$name.$type";
    }

    // --- HEIC / TIFF: ubah ke JPG (butuh Imagick) ---
    if (in_array($type, ['heic', 'tiff'], true)) {
        if (imagick_to_jpg($tmp, "$dir/$name.jpg", $max)) return "$name.jpg";
        image_error('Format ' . strtoupper($type) . ' belum bisa diproses di server ini. '
                  . 'Ubah dulu ke JPG atau PNG (di HP: Pengaturan Kamera → Format → "Paling Kompatibel"), lalu unggah lagi.');
        return null;
    }

    // --- JPG / PNG / WEBP / BMP ---
    [$w, $h] = @getimagesize($tmp) ?: [0, 0];
    $big = max($w, $h) > $max;

    if (!$big && $type !== 'bmp') {                       // sudah pas → simpan asli (kualitas utuh)
        move_uploaded_file($tmp, "$dir/$name.$type");
        return "$name.$type";
    }

    $src = gd_load($tmp, $type);
    if (!$src) {                                          // GD tidak bisa membaca → simpan asli
        move_uploaded_file($tmp, "$dir/$name.$type");
        return "$name.$type";
    }

    if ($type === 'jpg') $src = gd_orient($tmp, $src);
    $sw = imagesx($src);
    $sh = imagesy($src);
    $k  = $big ? $max / max($sw, $sh) : 1;
    $nw = max(1, (int)round($sw * $k));
    $nh = max(1, (int)round($sh * $k));

    $dst = imagecreatetruecolor($nw, $nh);
    if ($type !== 'jpg') {                                // pertahankan transparansi
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $sw, $sh);

    if ($type === 'jpg')      { $ext = 'jpg';  $ok = imagejpeg($dst, "$dir/$name.jpg", 88); }
    elseif ($type === 'webp' && function_exists('imagewebp')) { $ext = 'webp'; $ok = imagewebp($dst, "$dir/$name.webp", 88); }
    else                      { $ext = 'png';  $ok = imagepng($dst, "$dir/$name.png", 6); }

    if (!$ok) {
        move_uploaded_file($tmp, "$dir/$name.$type");
        return "$name.$type";
    }
    return "$name.$ext";
}