<?php
function user() {
    static $u = false;
    if ($u === false) {
        $u = isset($_SESSION['uid']) ? row('SELECT * FROM users WHERE id=?', [$_SESSION['uid']]) : null;
    }
    return $u;
}

function need_login() {
    if (!user()) { flash('Silakan masuk terlebih dahulu'); go('login'); }
}

function need_admin() {
    $u = user();
    if (!$u || $u['role'] !== 'admin') go('login');
}