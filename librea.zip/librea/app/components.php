<?php

// Sampul buku: foto jika ada, kalau tidak gradien dengan judul.
function cover($b) {
    if (!empty($b['cover'])) {
        return '<div class="cv ph"><img src="' . url('uploads/books/' . e($b['cover'])) . '" alt=""></div>';
    }
    return '<div class="cv c' . ((int)($b['id'] ?? 0) % 4) . '"><small>LIBRÉA</small><b>'
         . e($b['title']) . '</b><small>' . e($b['author'] ?? '') . '</small></div>';
}

// Avatar bulat: foto profil atau huruf pertama nama.
function avatar($u, $class = '') {
    if (!empty($u['photo'])) {
        return '<span class="av ' . $class . '"><img src="' . url('uploads/avatars/' . e($u['photo'])) . '" alt=""></span>';
    }
    return '<span class="av ' . $class . '">' . e(mb_strtoupper(mb_substr($u['name'] ?? '?', 0, 1))) . '</span>';
}

// Bintang rating (1–5).
function stars($n) {
    $html = '<span class="stars">';
    for ($i = 1; $i <= 5; $i++) {
        $html .= '<svg viewBox="0 0 24 24" class="' . ($i <= round($n) ? 'on' : '') . '">'
               . '<path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
    }
    return $html . '</span>';
}

// Kelas warna untuk status pesanan.
function status_class($status) {
    return ['Menunggu Pembayaran' => 'st1', 'Dibayar' => 'st2', 'Dikirim' => 'st3', 'Selesai' => 'st4'][$status] ?? 'st1';
}

// Tampilan "belum ada data". Gayanya ada di assets/css/empty.css.
// Ikon yang tersedia: receipt, star, chat, heart, book.
function empty_state($ic, $title, $desc, $btnLabel = null, $btnUrl = null) {
    // ilustrasi dua warna (putih penuh + putih transparan + aksen ungu/pink)
    $art = [
        // struk pesanan dengan lencana centang
        'receipt' => '<rect x="8" y="9" width="26" height="31" rx="5" fill="#fff" opacity=".35" transform="rotate(-8 21 24)"/>'
                   . '<path d="M16 6h16a3 3 0 0 1 3 3v33l-3.67-2.5L27.67 42 24 39.5 20.33 42l-3.66-2.5L13 42V9a3 3 0 0 1 3-3z" fill="#fff"/>'
                   . '<rect x="17.5" y="14" width="13" height="3" rx="1.5" fill="#8b5cf6" opacity=".55"/>'
                   . '<rect x="17.5" y="21" width="13" height="3" rx="1.5" fill="#8b5cf6" opacity=".55"/>'
                   . '<rect x="17.5" y="28" width="7" height="3" rx="1.5" fill="#ec4899" opacity=".75"/>'
                   . '<circle cx="36" cy="35" r="7.5" fill="#ec4899" stroke="#fff" stroke-width="2.2"/>'
                   . '<path d="M32.7 35.2l2.3 2.3 4.2-4.4" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>',

        // bintang besar dengan bintang kecil dan kilau
        'star'    => '<g transform="translate(2.6 5) scale(1.72)"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z" fill="#fff"/></g>'
                   . '<g transform="translate(30 1.5) scale(.62)"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z" fill="#fff" opacity=".55"/></g>'
                   . '<path d="M8 6v7M4.5 9.5h7" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".75"/>'
                   . '<circle cx="42" cy="38" r="2.4" fill="#fff" opacity=".6"/>',

        // dua balon chat bertumpuk
        'chat'    => '<path d="M6 12a5 5 0 0 1 5-5h18a5 5 0 0 1 5 5v9a5 5 0 0 1-5 5H17l-6 5v-5a5 5 0 0 1-5-5z" fill="#fff" opacity=".4"/>'
                   . '<path d="M16 20a5 5 0 0 1 5-5h18a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5h-2v6l-7-6H21a5 5 0 0 1-5-5z" fill="#fff"/>'
                   . '<circle cx="24" cy="25" r="2.2" fill="#8b5cf6"/><circle cx="30.5" cy="25" r="2.2" fill="#ec4899"/><circle cx="37" cy="25" r="2.2" fill="#8b5cf6"/>',

        // hati besar dengan kilau
        'heart'   => '<path d="M24 40.5C10 31 6 24 6 17.5 6 12.8 9.6 9.5 14 9.5c3.7 0 7 2.2 10 6.2 3-4 6.3-6.2 10-6.2 4.4 0 8 3.3 8 8 0 6.5-4 13.5-18 23z" fill="#fff"/>'
                   . '<path d="M13 19a5.5 5.5 0 0 1 5.5-5.5" fill="none" stroke="#ec4899" stroke-width="2.6" stroke-linecap="round" opacity=".55"/>'
                   . '<path d="M41 4v7M37.5 7.5h7" stroke="#fff" stroke-width="2.4" stroke-linecap="round" opacity=".8"/>'
                   . '<circle cx="7" cy="40" r="2.4" fill="#fff" opacity=".6"/>',

        // buku terbuka
        'book'    => '<path d="M5 12c6-2.4 13-1.4 19 3v25c-6-4.4-13-5.4-19-3z" fill="#fff" opacity=".55"/>'
                   . '<path d="M43 12c-6-2.4-13-1.4-19 3v25c6-4.4 13-5.4 19-3z" fill="#fff"/>',
    ];
    $tone = ['receipt' => 'nd-t0', 'star' => 'nd-t1', 'chat' => 'nd-t2', 'heart' => 'nd-t0', 'book' => 'nd-t1'];
    $key  = isset($art[$ic]) ? $ic : 'book';

    $html  = '<div class="nd-box">';
    $html .=   '<div class="nd-ico ' . $tone[$key] . '">';
    $html .=     '<svg width="52" height="52" viewBox="0 0 48 48" aria-hidden="true">' . $art[$key] . '</svg>';
    $html .=   '</div>';
    $html .=   '<div class="nd-txt"><h3>' . e($title) . '</h3><p>' . e($desc) . '</p></div>';
    if ($btnLabel && $btnUrl) {
        $html .= '<a class="btn" href="' . e($btnUrl) . '">' . e($btnLabel) . '</a>';
    }
    return $html . '</div>';
}

// ---------- Gambar statis di assets/img/ (semua jenis file) ----------
// Cukup nama dasarnya: 'logo', 'hero1', 'pay/bca' — ekstensi dicari otomatis.
// Nama dengan ekstensi ('logo.png') tetap boleh dipakai.
function find_img($file) {
    $base = preg_replace('/\.(png|jpe?g|webp|gif|svg|avif)$/i', '', $file);
    foreach (['png', 'jpg', 'jpeg', 'webp', 'svg', 'gif', 'avif'] as $ext) {
        if (file_exists(ROOT . "/assets/img/$base.$ext")) return "assets/img/$base.$ext";
    }
    return null;
}

function img_slot($file) {
    $p = find_img($file);
    if (!$p) return '<span class="phi">' . icon('image') . '</span>';
    return '<img src="' . url($p) . '?v=' . filemtime(ROOT . '/' . $p) . '" alt="">';   // ?v= agar foto baru langsung tampil
}

// ---------- Ikon metode pembayaran (kartu di halaman checkout) ----------
function pay_icon($key) {
    if ($p = find_img("pay/$key")) {
        return '<span class="pi-ic has"><img src="' . url($p) . '?v=' . filemtime(ROOT . '/' . $p) . '" alt=""></span>';
    }
    $art = [
        // gedung bank
        'bank'    => '<path d="M24 5L5 15.5V20h38v-4.5z" fill="#fff"/>'
                   . '<circle cx="24" cy="14" r="2.2" fill="#8b5cf6"/>'
                   . '<rect x="9" y="23" width="6" height="14" rx="2" fill="#fff" opacity=".88"/>'
                   . '<rect x="21" y="23" width="6" height="14" rx="2" fill="#fff" opacity=".88"/>'
                   . '<rect x="33" y="23" width="6" height="14" rx="2" fill="#fff" opacity=".88"/>'
                   . '<rect x="5" y="39" width="38" height="5" rx="2.5" fill="#fff"/>',
        // kode QR
        'qris'    => '<rect x="6" y="6" width="15" height="15" rx="3.5" fill="none" stroke="#fff" stroke-width="3"/>'
                   . '<rect x="11" y="11" width="5" height="5" rx="1.2" fill="#fff"/>'
                   . '<rect x="27" y="6" width="15" height="15" rx="3.5" fill="none" stroke="#fff" stroke-width="3"/>'
                   . '<rect x="32" y="11" width="5" height="5" rx="1.2" fill="#fff"/>'
                   . '<rect x="6" y="27" width="15" height="15" rx="3.5" fill="none" stroke="#fff" stroke-width="3"/>'
                   . '<rect x="11" y="32" width="5" height="5" rx="1.2" fill="#fff"/>'
                   . '<rect x="27" y="27" width="6" height="6" rx="1.5" fill="#fff"/>'
                   . '<rect x="36" y="27" width="6" height="6" rx="1.5" fill="#fff" opacity=".7"/>'
                   . '<rect x="27" y="36" width="6" height="6" rx="1.5" fill="#fff" opacity=".7"/>'
                   . '<rect x="36" y="36" width="6" height="6" rx="1.5" fill="#fff"/>',
        // dompet
        'ewallet' => '<rect x="9" y="6" width="30" height="16" rx="4" fill="#fff" opacity=".45" transform="rotate(-9 24 14)"/>'
                   . '<rect x="5" y="14" width="38" height="27" rx="7" fill="#fff"/>'
                   . '<rect x="27" y="23" width="16" height="11" rx="5.5" fill="#8b5cf6" opacity=".85"/>'
                   . '<circle cx="33.5" cy="28.5" r="2.3" fill="#fff"/>',
    ];
    $tone = ['bank' => 'pt0', 'qris' => 'pt1', 'ewallet' => 'pt2'];
    $k    = isset($art[$key]) ? $key : 'bank';
    return '<span class="pi-ic ' . $tone[$k] . '"><svg viewBox="0 0 48 48" aria-hidden="true">' . $art[$k] . '</svg></span>';
}

// ---------- Kotak bank / e-wallet (daftar pilihan di halaman pembayaran) ----------
function prov_tile($key, $name) {
    if ($p = find_img("pay/$key")) {
        return '<span class="pi-ic has"><img src="' . url($p) . '?v=' . filemtime(ROOT . '/' . $p) . '" alt=""></span>';
    }
    $short = ['bca' => 'BCA', 'mandiri' => 'MDR', 'permata' => 'PMT', 'bri' => 'BRI', 'bni' => 'BNI',
              'gopay' => 'GP', 'dana' => 'DANA', 'ovo' => 'OVO'];
    $tone  = ['bca' => 'pt1', 'mandiri' => 'pt1', 'permata' => 'pt0', 'bri' => 'pt1', 'bni' => 'pt2',
              'gopay' => 'pt1', 'dana' => 'pt1', 'ovo' => 'pt0'];
    return '<span class="pi-ic txt ' . ($tone[$key] ?? 'pt0') . '">' . e($short[$key] ?? strtoupper(substr($name, 0, 3))) . '</span>';
}

// ---------- Logo: ikon buku terbuka (SVG buatan sendiri, dua warna) ----------
function brand_icon() {
    return '<span class="brand-ic"><svg viewBox="0 0 48 48" aria-hidden="true">'
         // halaman kiri & kanan
         . '<path d="M4 12c7-2.8 14.5-1.6 20 3.4v25.2C18.500 36.400 11 35.200 4 38z" fill="#fff" opacity=".6"/>'
         . '<path d="M44 12c-7-2.8-14.5-1.6-20 3.4v25.2c5.500-4.200 13-5.400 20-2.600z" fill="#fff"/>'
         // garis teks pada halaman kanan
         . '<path d="M28.500 20.500c3.400-1.100 6.800-1.200 10.500-.4" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" fill="none" opacity=".55"/>'
         . '<path d="M28.500 26c3.400-1.100 6.800-1.200 10.500-.4" stroke="#ec4899" stroke-width="2" stroke-linecap="round" fill="none" opacity=".65"/>'
         . '<path d="M28.500 31.500c2.600-.8 5.100-1 7.800-.5" stroke="#8b5cf6" stroke-width="2" stroke-linecap="round" fill="none" opacity=".45"/>'
         // kilau di atas buku
         . '<path d="M24 2.500l1.700 4.100 4.100 1.700-4.100 1.700L24 14.100l-1.700-4.100-4.100-1.700 4.100-1.700z" fill="#fff"/>'
         . '</svg></span>';
}