<?php
// ==========================================================================
// cancel.php — pembatalan pesanan & pengembalian dana
// ==========================================================================

// Pilihan tujuan pengembalian untuk pembayaran QRIS
const REFUND_TO = ['GoPay', 'DANA', 'OVO', 'BCA', 'Mandiri', 'Permata', 'BRI', 'BNI'];

// ---------- Alasan pembatalan ----------
function cancel_reasons($by) {
    if ($by === 'admin') {
        return [
            'Stok buku habis atau rusak',
            'Bukti pembayaran tidak valid',
            'Nominal pembayaran tidak sesuai',
            'Alamat pengiriman tidak dapat dijangkau',
            'Data penerima tidak lengkap atau tidak jelas',
            'Atas permintaan pembeli',
            'Lainnya',
        ];
    }
    return [
        'Salah memilih produk atau jumlah',
        'Ingin mengubah alamat atau data penerima',
        'Menemukan harga yang lebih murah',
        'Memesan secara tidak sengaja atau pesanan ganda',
        'Waktu pengiriman terlalu lama',
        'Ingin mengganti metode pembayaran',
        'Lainnya',
    ];
}

// ---------- Aturan: kapan boleh dibatalkan ----------
function can_user_cancel($o)  { return in_array($o['status'], ['Menunggu Pembayaran', 'Dibayar'], true); }
function can_admin_cancel($o) { return in_array($o['status'], ['Menunggu Pembayaran', 'Dibayar', 'Dikirim'], true); }

// ---------- Ikon kecil ----------
function cx_icon($name) {
    $p = [
        'x'      => '<path d="M6 6l12 12M18 6L6 18"/>',
        'wallet' => '<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10V8a2 2 0 0 1 2-2h11"/><path d="M16 13h2"/>',
        'info'   => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
        'ok'     => '<path d="M5 12l5 5L20 7"/>',
    ];
    return '<svg class="i" viewBox="0 0 24 24">' . ($p[$name] ?? '') . '</svg>';
}

function cx_date($d) {
    return $d ? date('d/m/Y H:i', strtotime($d)) : '-';
}

// ---------- Label status pesanan (termasuk "Dibatalkan") ----------
function order_badge($o) {
    if ($o['status'] === 'Dibatalkan') return '<span class="st st5"><i class="sd"></i>Dibatalkan</span>';
    return '<span class="st ' . status_class($o['status']) . '"><i class="sd"></i>' . e($o['status']) . '</span>';
}

// ---------- Penanda tahap pengembalian dana ----------
function cx_tracker($o) {
    $steps = ['Pesanan dibatalkan', 'Data rekening', 'Dana dikembalikan', 'Dikonfirmasi'];
    $idx   = ['Menunggu Data Rekening' => 1, 'Menunggu Pengembalian Dana' => 2, 'Dana Dikembalikan' => 3, 'Selesai' => 4][$o['refund_status']] ?? 1;

    $h = '<div class="cx-trk">';
    foreach ($steps as $i => $s) {
        $cls = $i < $idx ? 'done' : ($i === $idx ? 'on' : '');
        $h .= '<div class="cx-st ' . $cls . '"><i>' . ($i < $idx ? cx_icon('ok') : ($i + 1)) . '</i><span>' . $s . '</span></div>';
    }
    return $h . '</div>';
}

// ---------- Kotak keterangan pembatalan ----------
function cx_banner($o, $viewer) {
    $who = $o['cancel_by'] === 'admin'
        ? 'oleh admin toko'
        : ($viewer === 'admin' ? 'oleh pembeli' : 'oleh kamu');

    $h  = '<div class="cx-banner"><span class="cx-bi">' . cx_icon('x') . '</span><div>';
    $h .= '<b>Pesanan dibatalkan ' . $who . '</b>';
    $h .= '<p>Alasan: ' . e($o['cancel_reason']) . '</p>';
    if (!empty($o['cancel_note'])) $h .= '<p class="cx-quote">“' . e($o['cancel_note']) . '”</p>';
    return $h . '<small>' . cx_date($o['cancelled_at']) . '</small></div></div>';
}

// ---------- Tujuan pengembalian dana ----------
function refund_dest($o, $copy = false) {
    $row = function ($label, $val, $c = '') {
        return '<div class="cx-d"><div><small>' . $label . '</small><b>' . e($val) . '</b></div>'
             . ($c !== '' ? '<button type="button" class="cx-copy" data-copy="' . e($c) . '">Salin</button>' : '')
             . '</div>';
    };
    return '<div class="cx-dest">'
         . $row('Dikembalikan ke', $o['refund_method'])
         . $row('Nomor', $o['refund_account'], $copy ? $o['refund_account'] : '')
         . $row('Atas nama', $o['refund_name'])
         . $row('Jumlah dana', rp($o['total']), $copy ? (string)(int)$o['total'] : '')
         . '</div>';
}

// ---------- Isian tujuan pengembalian (menyesuaikan metode bayar) ----------
function refund_fields($o, $v = []) {
    $m    = $o['method'];
    $prov = $o['provider'];
    $h    = '';

    if ($m === 'Transfer Bank') {
        $h .= '<label>Bank tujuan</label><input name="refund_method" value="' . e($v['method'] ?? $prov) . '" required>';
        $no = 'No. rekening';
    } elseif ($m === 'E-Wallet') {
        $h .= '<input type="hidden" name="refund_method" value="' . e($prov) . '">'
            . '<div class="cx-fixed">' . cx_icon('wallet') . 'Dana dikembalikan ke <b>' . e($prov) . '</b></div>';
        $no = 'Nomor ' . e($prov);
    } else {                                            // QRIS
        $h .= '<label>Kirim pengembalian ke</label><select name="refund_method" required>';
        foreach (REFUND_TO as $t) $h .= '<option>' . $t . '</option>';
        $h .= '</select>';
        $no = 'No. rekening / e-wallet';
    }

    $h .= '<label>' . $no . '</label><input name="refund_account" inputmode="numeric" placeholder="Hanya angka" required>';
    $h .= '<label>Atas nama</label><input name="refund_name" placeholder="Nama pemilik rekening / akun" required>';
    return $h;
}

function parse_refund_post() {
    $m = trim($_POST['refund_method'] ?? '');
    $a = preg_replace('/[\s-]/', '', $_POST['refund_account'] ?? '');
    $n = trim($_POST['refund_name'] ?? '');

    if ($m === '' || mb_strlen($m) > 40)       return [null, 'Pilih tujuan pengembalian dana'];
    if (!preg_match('/^\d{5,20}$/', $a))       return [null, 'Nomor rekening atau e-wallet harus 5–20 angka'];
    if (mb_strlen($n) < 2)                     return [null, 'Isi nama pemilik rekening atau akun'];
    return [['method' => $m, 'account' => $a, 'name' => $n], ''];
}

// ---------- Proses pembatalan (dipakai user & admin) ----------
// $acc diisi jika tujuan pengembalian sudah ada (pembatalan oleh user)
function cancel_order($o, $by, $reason, $note, $acc = null) {
    global $pdo;
    try {
        $pdo->beginTransaction();

        $ok = q("UPDATE orders SET status='Dibatalkan', cancel_by=?, cancel_reason=?, cancel_note=?, cancelled_at=NOW(),
                        refund_status=?, refund_method=?, refund_account=?, refund_name=?
                 WHERE id=? AND status IN ('Menunggu Pembayaran','Dibayar','Dikirim')",
                [$by, $reason, $note, $acc ? 'Menunggu Pengembalian Dana' : 'Menunggu Data Rekening',
                 $acc['method'] ?? null, $acc['account'] ?? null, $acc['name'] ?? null, $o['id']])->rowCount();
        if (!$ok) throw new Exception('Status pesanan sudah berubah');

        // stok kembali (kecuali buku sudah dikirim)
        if (in_array($o['status'], ['Menunggu Pembayaran', 'Dibayar'], true)) {
            foreach (rows('SELECT book_id, qty FROM order_items WHERE order_id=? AND book_id IS NOT NULL', [$o['id']]) as $it) {
                q('UPDATE books SET stock = stock + ? WHERE id=?', [$it['qty'], $it['book_id']]);
            }
        }
        $pdo->commit();
        return true;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return false;
    }
}

// ---------- CSS & JS (dimuat langsung di halaman yang memakai fitur ini) ----------
function cx_css() {
    return '<link rel="stylesheet" href="' . url('assets/css/cancel.css') . '?v=' . (int)@filemtime(ROOT . '/assets/css/cancel.css') . '">';
}

function cx_script() {
    return <<<'JS'
<script>
(function () {
  // buka popup: tombol dengan data-dlg="id"
  document.querySelectorAll('[data-dlg]').forEach(function (b) {
    b.addEventListener('click', function (e) {
      e.preventDefault();
      var d = document.getElementById(b.dataset.dlg);
      if (d) d.showModal();
    });
  });
  // tutup popup: data-x, klik area gelap, atau Esc
  document.querySelectorAll('dialog.cx-dlg').forEach(function (d) {
    d.querySelectorAll('[data-x]').forEach(function (x) { x.addEventListener('click', function () { d.close(); }); });
    d.addEventListener('click', function (e) { if (e.target === d) d.close(); });
  });
  // tombol salin
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
      var t = btn.dataset.copy;
      try { await navigator.clipboard.writeText(t); }
      catch (e) {
        var i = document.createElement('input'); i.value = t; document.body.appendChild(i);
        i.select(); document.execCommand('copy'); i.remove();
      }
      var old = btn.textContent; btn.textContent = 'Tersalin ✓';
      setTimeout(function () { btn.textContent = old; }, 1600);
    });
  });
  // tampilkan nama file yang dipilih
  document.querySelectorAll('input[type=file][data-fn]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var lb = document.querySelector('label[for="' + inp.id + '"] b');
      if (lb && inp.files[0]) lb.textContent = inp.files[0].name;
    });
  });
})();
</script>
JS;
}