</main>

<footer>© 2026 Libréa · Setiap halaman, sebuah dunia ✦</footer>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>