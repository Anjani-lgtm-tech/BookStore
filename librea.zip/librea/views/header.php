<?php
$u      = user();
$cats   = rows('SELECT c.*, (SELECT COUNT(*) FROM books WHERE category_id = c.id) AS n FROM categories c ORDER BY c.name');
$cartN  = $u ? (int)val('SELECT COALESCE(SUM(qty),0) FROM cart WHERE user_id=?', [$u['id']]) : 0;
$catSel = (int)($_GET['cat'] ?? 0);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title ?? 'Libréa — Toko Buku Online') ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php foreach (['base', 'layout', 'components', 'pages', 'book', 'modal', 'empty', 'extras'] as $css): ?>        <link rel="stylesheet" href="<?= url("assets/css/$css.css") ?>">
    <?php endforeach; ?>
</head>
<body>

<nav>
    <a class="logo" href="<?= route('home') ?>">
        <?= brand_icon() ?>
        <span class="lt">Libréa</span>
    </a>

    <div class="nlinks">
        <a class="<?= $current === 'home' && !$catSel ? 'on' : '' ?>" href="<?= route('home') ?>">Beranda</a>
        <a class="<?= $current === 'about' ? 'on' : '' ?>"   href="<?= route('about') ?>">About Us</a>
        <a class="<?= $current === 'contact' ? 'on' : '' ?>" href="<?= route('contact') ?>">Kontak</a>

        <details class="ndd">
            <summary class="<?= $catSel ? 'on' : '' ?>">Kategori <?= icon('chev') ?></summary>
            <div class="cddm">
                <a class="cdo" href="<?= route('home') ?>#kat"><?= icon('grid') ?><span>Semua Kategori</span></a>
                <?php foreach ($cats as $c): ?>
                    <a class="cdo <?= $catSel == $c['id'] ? 'on' : '' ?>" href="<?= route('home', ['cat' => $c['id']]) ?>#kat">
                        <?= icon($c['icon']) ?><span><?= e($c['name']) ?></span><em><?= $c['n'] ?></em>
                    </a>
                <?php endforeach; ?>
            </div>
        </details>
    </div>

    <div class="nright">
        <a class="nic" href="<?= route('cart') ?>" title="Keranjang">
            <?= icon('cart') ?>
            <?php if ($cartN): ?><span class="badge"><?= $cartN ?></span><?php endif; ?>
        </a>

        <?php if ($u && $u['role'] === 'user'): ?>
            <a class="nprof" href="<?= route('profile') ?>"><?= avatar($u) ?><?= e(explode(' ', $u['name'])[0]) ?></a>
        <?php else: ?>
            <a class="nlogin" href="<?= route('login') ?>">Masuk</a>
            <a class="btn" href="<?= route('register') ?>">Daftar</a>
        <?php endif; ?>
    </div>
</nav>

<?php if ($f = flash()): ?><div class="toast"><?= e($f) ?></div><?php endif; ?>

<main>