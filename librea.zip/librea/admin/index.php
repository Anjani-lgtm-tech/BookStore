<?php
require __DIR__ . '/../app/bootstrap.php';
need_admin();

$menu = [                                   // kunci => [judul, ikon]
    'books'      => ['Buku',     'book'],
    'categories' => ['Kategori', 'tag'],
    'users'      => ['User',     'users'],
    'orders'     => ['Pesanan',  'receipt'],
    'reviews'    => ['Ulasan',   'star'],
    'messages'   => ['Pesan',    'chat'],
];

$current = $_GET['page'] ?? 'books';
if (!isset($menu[$current])) $current = 'books';
$title = $menu[$current][0];

require __DIR__ . "/pages/$current.php";