<?php
// ---------- Hapus ulasan ----------
if (isset($_POST['delete'])) {
    q('DELETE FROM reviews WHERE id=?', [(int)$_POST['id']]);
    flash('Ulasan dihapus');
    admin_go('reviews', !empty($_GET['r']) ? ['r' => (int)$_GET['r']] : []);
}

// ---------- Data ----------
$filter = (int)($_GET['r'] ?? 0);                 // 0 = semua, 1–5 = bintang tertentu

$all = rows('SELECT r.*, u.name, u.photo,
                    b.id AS bid, b.title, b.author, b.cover,
                    o.order_code
             FROM reviews r
             JOIN users u ON u.id = r.user_id
             JOIN books b ON b.id = r.book_id
             LEFT JOIN orders o ON o.id = r.order_id
             ORDER BY r.id DESC');

$total = count($all);
$avg   = $total ? round(array_sum(array_column($all, 'rating')) / $total, 1) : 0;

$dist = array_fill(1, 5, 0);                      // jumlah ulasan per bintang
foreach ($all as $r) $dist[(int)$r['rating']]++;

$list = $filter
    ? array_values(array_filter($all, fn($r) => (int)$r['rating'] === $filter))
    : $all;

require __DIR__ . '/../layout/header.php';
?>

<link rel="stylesheet" href="<?= url('assets/css/reviews.css') ?>?v=<?= (int)@filemtime(ROOT . '/assets/css/reviews.css') ?>">

<?php if ($total): ?>

    <!-- ===================== RINGKASAN ===================== -->
    <div class="rw-sum">
        <div class="rw-score">
            <b><?= number_format($avg, 1) ?></b>
            <?= stars($avg) ?>
            <small>dari <?= $total ?> ulasan</small>
        </div>

        <div class="rw-bars">
            <?php for ($s = 5; $s >= 1; $s--):
                $pct = round($dist[$s] / $total * 100);
            ?>
                <a class="rw-bar <?= $filter === $s ? 'on' : '' ?>" href="<?= admin_url('reviews', ['r' => $s]) ?>">
                    <span><?= $s ?> ★</span>
                    <i><u style="width:<?= $pct ?>%"></u></i>
                    <em><?= $dist[$s] ?></em>
                </a>
            <?php endfor; ?>
        </div>
    </div>

    <?php if ($filter): ?>
        <a class="rw-reset" href="<?= admin_url('reviews') ?>">← Tampilkan semua ulasan</a>
    <?php endif; ?>

<?php endif; ?>


<!-- ===================== DAFTAR ULASAN ===================== -->
<?php foreach ($list as $r): ?>
    <article class="rw-card">

        <!-- buku yang diulas -->
        <a class="rw-book" href="<?= route('book', ['id' => $r['bid']]) ?>" target="_blank" title="Lihat halaman buku">
            <div class="rw-cover">
                <?= cover(['id' => $r['bid'], 'title' => $r['title'], 'author' => $r['author'], 'cover' => $r['cover']]) ?>
            </div>
            <b><?= e($r['title']) ?></b>
            <small><?= e($r['author']) ?></small>
        </a>

        <!-- isi ulasan -->
        <div class="rw-main">
            <div class="rw-top">
                <?= avatar($r) ?>
                <div class="rw-who">
                    <b><?= e($r['name']) ?></b>
                    <small><?= date('d/m/Y · H:i', strtotime($r['created_at'])) ?></small>
                </div>
                <div class="rw-rate">
                    <?= stars($r['rating']) ?>
                    <em class="rw-num"><?= number_format((float)$r['rating'], 1) ?></em>
                </div>
            </div>

            <?php if ($r['comment']): ?>
                <p class="rw-text"><?= nl2br(e($r['comment'])) ?></p>
            <?php else: ?>
                <p class="rw-text none">Pembeli tidak menulis komentar.</p>
            <?php endif; ?>

            <div class="rw-foot">
                <span class="rw-ok"><?= icon('check') ?>Pembelian terverifikasi</span>
                <?php if ($r['order_code']): ?><span class="rw-ord">#<?= e($r['order_code']) ?></span><?php endif; ?>

                <form method="post" onsubmit="return confirm('Hapus ulasan ini?')">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <button class="rw-del" name="delete" value="1"><?= icon('trash') ?>Hapus</button>
                </form>
            </div>
        </div>

    </article>
<?php endforeach; ?>


<!-- ===================== KOSONG ===================== -->
<?php if (!$list): ?>
    <?php if ($filter): ?>
        <?= empty_state('star', 'Tidak ada ulasan ' . $filter . ' bintang', 'Belum ada pembeli yang memberi rating ' . $filter . ' untuk buku mana pun.', 'Tampilkan Semua', admin_url('reviews')) ?>
    <?php else: ?>
        <?= empty_state('star', 'Belum ada ulasan', 'Ulasan muncul setelah pembeli menilai buku dari pesanan yang berstatus Selesai.', 'Lihat Pesanan', admin_url('orders')) ?>
    <?php endif; ?>
<?php endif; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>