<?php
// ---------- Hapus ----------
if (isset($_POST['delete'])) {
    try {
        q('DELETE FROM categories WHERE id=?', [(int)$_POST['id']]);
        flash('Kategori dihapus');
    } catch (PDOException $ex) {
        flash('Kategori masih dipakai oleh buku');
    }
    admin_go('categories');
}

// ---------- Simpan ----------
if (isset($_POST['save'])) {
    $id   = (int)$_POST['id'];
    $name = trim($_POST['name']);
    $icon = in_array($_POST['icon'] ?? '', $CAT_ICONS, true) ? $_POST['icon'] : guess_icon($name);

    if ($name !== '') {
        $id ? q('UPDATE categories SET name=?, icon=? WHERE id=?', [$name, $icon, $id])
            : q('INSERT INTO categories (name, icon) VALUES (?,?)', [$name, $icon]);
        flash('Kategori disimpan ✓');
    }
    admin_go('categories');
}

// ---------- Data ----------
$edit     = isset($_GET['edit']) ? row('SELECT * FROM categories WHERE id=?', [(int)$_GET['edit']]) : null;
$showForm = isset($_GET['new']) || $edit;
$cats     = rows('SELECT c.*, (SELECT COUNT(*) FROM books WHERE category_id = c.id) AS n FROM categories c ORDER BY c.name');

require __DIR__ . '/../layout/header.php';
?>

<div class="tbar">
    <b><?= count($cats) ?> kategori</b>
    <a class="btn" href="<?= admin_url('categories', ['new' => 1]) ?>#form">+ Tambah Kategori</a>
</div>

<?php if ($showForm): ?>
    <div class="box" id="form" style="margin-bottom:22px">
        <h3><?= $edit ? 'Edit' : 'Tambah' ?> Kategori</h3>
        <form method="post">
            <input type="hidden" name="id" value="<?= $edit['id'] ?? 0 ?>">

            <label>Nama kategori</label>
            <input name="name" value="<?= e($edit['name'] ?? '') ?>" placeholder="Contoh: Horor, Kuliner, Teknologi" required>

            <label>Ikon <small>(jika tidak dipilih, ikon dicocokkan otomatis dari nama)</small></label>
            <div class="igp">
                <?php foreach ($CAT_ICONS as $key): ?>
                    <label class="igb">
                        <input type="radio" name="icon" value="<?= $key ?>" <?= $edit && $edit['icon'] === $key ? 'checked' : '' ?>>
                        <span><?= icon($key) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <br>
            <button class="btn" name="save" value="1">Simpan</button>
            <a class="btn o" href="<?= admin_url('categories') ?>">Batal</a>
        </form>
    </div>
<?php endif; ?>

<div class="cgrid">
    <?php foreach ($cats as $i => $c): ?>
        <div class="ctile">
            <div class="cico c<?= $i % 4 ?>"><?= icon($c['icon']) ?></div>
            <div style="flex:1; min-width:0"><b><?= e($c['name']) ?></b><small><?= $c['n'] ?> buku</small></div>
            <div class="bact">
                <a class="ib" title="Edit" href="<?= admin_url('categories', ['edit' => $c['id']]) ?>#form"><?= icon('edit') ?></a>
                <form method="post" onsubmit="return confirm('Hapus kategori ini?')">
                    <input type="hidden" name="id" value="<?= $c['id'] ?>">
                    <button class="ib d" name="delete" value="1" title="Hapus"><?= icon('trash') ?></button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php require __DIR__ . '/../layout/footer.php'; ?>