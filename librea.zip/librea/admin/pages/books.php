<?php
$cats = rows('SELECT * FROM categories ORDER BY name');

// ---------- Hapus ----------
if (isset($_POST['delete'])) {
    q('DELETE FROM books WHERE id=?', [(int)$_POST['id']]);
    flash('Buku dihapus');
    admin_go('books');
}

// ---------- Simpan (tambah / edit) ----------
if (isset($_POST['save'])) {
    $id         = (int)$_POST['id'];
    $cover      = save_image('cover', 'books');
    $coverError = image_error();                 // '' jika tidak ada masalah
    $data       = [
        (int)$_POST['category_id'], trim($_POST['title']), trim($_POST['author']),
        (int)$_POST['price'], (int)$_POST['stock'], trim($_POST['description']),
        trim($_POST['publisher']), (int)$_POST['year'], (int)$_POST['pages'], trim($_POST['isbn']),
    ];

    if ($id) {
        q('UPDATE books SET category_id=?, title=?, author=?, price=?, stock=?, description=?, publisher=?, year=?, pages=?, isbn=?'
          . ($cover ? ', cover=?' : '') . ' WHERE id=?',
          array_merge($data, $cover ? [$cover] : [], [$id]));
    } else {
        q('INSERT INTO books (category_id, title, author, price, stock, description, publisher, year, pages, isbn, cover)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)', array_merge($data, [$cover]));
    }

    flash($coverError !== ''
        ? 'Buku disimpan, tetapi foto sampul gagal: ' . $coverError
        : 'Buku disimpan ✓');
    admin_go('books');
}

// ---------- Data ----------
$edit     = isset($_GET['edit']) ? row('SELECT * FROM books WHERE id=?', [(int)$_GET['edit']]) : null;
$showForm = isset($_GET['new']) || $edit;        // true → tampilkan form saja, daftar disembunyikan
$b        = $edit ?: [];
$books    = $showForm ? [] : rows('SELECT * FROM books ORDER BY title');

require __DIR__ . '/../layout/header.php';
?>

<?php if ($showForm): ?>

    <!-- ===================== FORM TAMBAH / EDIT (daftar buku disembunyikan) ===================== -->
    <a class="back" href="<?= admin_url('books') ?>">← Kembali ke daftar buku</a>

    <div class="box">
        <h3><?= $edit ? 'Edit' : 'Tambah' ?> Buku</h3>
        <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="id" value="<?= $b['id'] ?? 0 ?>">

            <label>Foto sampul</label>
            <div class="pv" id="pvb"><?= !empty($b['cover']) ? '<img src="' . url('uploads/books/' . e($b['cover'])) . '" alt="">' : '<span>Belum ada foto</span>' ?></div>
            <input type="file" name="cover" accept="image/*,.heic,.heif,.avif,.svg,.bmp,.tif,.tiff" data-preview="pvb">
            <small>JPG, PNG, WEBP, GIF, BMP, AVIF, SVG · maks. 20 MB. Foto besar diperkecil otomatis.</small>

            <div class="g2">
                <div><label>Judul</label>          <input name="title" value="<?= e($b['title'] ?? '') ?>" required></div>
                <div><label>Penulis</label>        <input name="author" value="<?= e($b['author'] ?? '') ?>" required></div>
                <div><label>Kategori</label>
                    <select name="category_id">
                        <?php foreach ($cats as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ($b['category_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select></div>
                <div><label>Harga (Rp)</label>     <input type="number" name="price" min="0" value="<?= e($b['price'] ?? '') ?>" required></div>
                <div><label>Stok</label>           <input type="number" name="stock" min="0" value="<?= e($b['stock'] ?? '') ?>" required></div>
                <div><label>Penerbit</label>       <input name="publisher" value="<?= e($b['publisher'] ?? '') ?>"></div>
                <div><label>Tahun terbit</label>   <input type="number" name="year" value="<?= e($b['year'] ?? '') ?>"></div>
                <div><label>Jumlah halaman</label> <input type="number" name="pages" value="<?= e($b['pages'] ?? '') ?>"></div>
            </div>
            <label>ISBN</label>      <input name="isbn" value="<?= e($b['isbn'] ?? '') ?>">
            <label>Deskripsi</label> <textarea name="description" rows="4"><?= e($b['description'] ?? '') ?></textarea>
            <br><br>
            <button class="btn" name="save" value="1">Simpan</button>
            <a class="btn o" href="<?= admin_url('books') ?>">Batal</a>
        </form>
    </div>

<?php else: ?>

    <!-- ===================== DAFTAR BUKU ===================== -->
    <div class="tbar">
        <b><?= count($books) ?> buku</b>
        <a class="btn" href="<?= admin_url('books', ['new' => 1]) ?>">+ Tambah Buku</a>
    </div>

    <?php foreach ($cats as $c):                              // dikelompokkan per kategori
        $list = array_filter($books, fn($x) => $x['category_id'] == $c['id']);
        if (!$list) continue;
    ?>
        <div class="cgh"><b><?= e($c['name']) ?></b><small><?= count($list) ?> buku</small></div>

        <?php foreach ($list as $x): ?>
            <div class="ar">
                <div class="bt">
                    <div class="cvw sm"><?= cover($x) ?></div>
                    <div><b><?= e($x['title']) ?></b><small><?= e($x['author']) ?></small></div>
                </div>
                <b class="bp"><?= rp($x['price']) ?></b>
                <span class="stk2 <?= $x['stock'] <= 5 ? 'low' : ($x['stock'] <= 15 ? 'mid' : 'ok') ?>"><?= $x['stock'] ?></span>
                <div class="bact">
                    <a class="ib" title="Edit" href="<?= admin_url('books', ['edit' => $x['id']]) ?>"><?= icon('edit') ?></a>
                    <form method="post" onsubmit="return confirm('Hapus buku ini?')">
                        <input type="hidden" name="id" value="<?= $x['id'] ?>">
                        <button class="ib d" name="delete" value="1" title="Hapus"><?= icon('trash') ?></button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endforeach; ?>

<?php endif; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?> 