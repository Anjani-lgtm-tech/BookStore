<?php
// ---------- Kirim / ubah balasan ----------
if (isset($_POST['reply']) && trim($_POST['text']) !== '') {
    q('UPDATE messages SET reply=?, replied_at=NOW() WHERE id=?', [trim($_POST['text']), (int)$_POST['id']]);
    flash('Balasan terkirim ✓');
    admin_go('messages');
}

$msgs = rows('SELECT m.*, u.name, u.email, u.photo
              FROM messages m JOIN users u ON u.id = m.user_id
              ORDER BY m.id DESC');

require __DIR__ . '/../layout/header.php';
?>

<?php foreach ($msgs as $m): ?>
    <div class="mc">
        <?= avatar($m) ?>

        <div style="flex:1; min-width:0">
            <div class="mh2">
                <b><?= e($m['name']) ?></b>
                <span class="cat"><?= e($m['email']) ?></span>
                <small><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></small>
            </div>

            <div class="msub"><?= e($m['subject']) ?></div>
            <p><?= nl2br(e($m['body'])) ?></p>

            <?php if ($m['reply']): ?>
                <div class="rpb">
                    <small>Balasanmu · <?= date('d/m/Y H:i', strtotime($m['replied_at'])) ?></small>
                    <?= nl2br(e($m['reply'])) ?>
                </div>
            <?php endif; ?>

            <details class="rvf">
                <summary class="btn o s"><?= $m['reply'] ? 'Ubah balasan' : 'Balas' ?></summary>
                <form method="post">
                    <input type="hidden" name="id" value="<?= $m['id'] ?>">
                    <textarea name="text" rows="3" placeholder="Tulis balasan untuk pengguna…"><?= e($m['reply']) ?></textarea>
                    <button class="btn s" name="reply" value="1">Kirim Balasan</button>
                </form>
            </details>
        </div>
    </div>
<?php endforeach; ?>

<?php if (!$msgs): ?>
    <?= empty_state('chat', 'Belum ada pesan', 'Pesan dari pengguna lewat halaman Kontak akan muncul di sini, lengkap dengan kolom balasan.') ?>
<?php endif; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>