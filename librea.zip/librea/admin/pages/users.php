<?php
$users = rows('SELECT u.*, (SELECT COUNT(*) FROM orders WHERE user_id = u.id) AS n FROM users u ORDER BY u.id');

require __DIR__ . '/../layout/header.php';
?>

<div class="tbar"><b><?= count($users) ?> pengguna terdaftar</b></div>

<div class="tl3h"><span>Pengguna</span><span>Role</span><span>Pesanan</span><span>Terdaftar</span></div>

<?php foreach ($users as $x): ?>
    <div class="ar tl3">
        <div class="bt">
            <?= avatar($x) ?>
            <div style="min-width:0">
                <b><?= e($x['name']) ?></b>
                <small><?= e($x['email']) ?></small>
                <?php if ($x['phone']): ?><small><?= e($x['phone']) ?></small><?php endif; ?>
            </div>
        </div>
        <span><i class="role <?= $x['role'] ?>"><?= $x['role'] === 'admin' ? 'Admin' : 'User' ?></i></span>
        <b><?= $x['n'] ?></b>
        <small><?= date('d/m/Y', strtotime($x['created_at'])) ?></small>
    </div>
<?php endforeach; ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>