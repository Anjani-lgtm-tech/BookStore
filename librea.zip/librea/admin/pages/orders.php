<?php
$steps = ['Menunggu Pembayaran', 'Dibayar', 'Dikirim', 'Selesai'];

// ---------- Filter ----------
$f     = $_GET['f'] ?? 'all';
$where = [
    'all'    => '1=1',
    'active' => "o.status <> 'Dibatalkan'",
    'cancel' => "o.status = 'Dibatalkan'",
    'refund' => "o.refund_status = 'Menunggu Pengembalian Dana'",
];
if (!isset($where[$f])) $f = 'all';
$back = $f === 'all' ? [] : ['f' => $f];

// ---------- Ubah status (pesanan yang sudah dibatalkan tidak bisa diubah) ----------
if (isset($_POST['status']) && in_array($_POST['status'], $steps, true)) {
    q("UPDATE orders SET status=? WHERE id=? AND status <> 'Dibatalkan'", [$_POST['status'], (int)$_POST['id']]);
    flash('Status diperbarui ✓');
    admin_go('orders', $back);
}

// ---------- Batalkan pesanan oleh admin ----------
if (isset($_POST['admin_cancel'])) {
    $o      = row('SELECT * FROM orders WHERE id=?', [(int)$_POST['id']]);
    $reason = $_POST['reason'] ?? '';
    $note   = trim($_POST['note'] ?? '');

    if (!$o || !can_admin_cancel($o)) {
        flash('Pesanan ini tidak dapat dibatalkan');
    } elseif (!in_array($reason, cancel_reasons('admin'), true)) {
        flash('Pilih alasan pembatalan');
    } elseif ($reason === 'Lainnya' && $note === '') {
        flash('Tulis alasannya pada kolom catatan');
    } elseif (cancel_order($o, 'admin', $reason, mb_substr($note, 0, 500))) {
        flash('Pesanan dibatalkan. Pembeli diminta mengisi tujuan pengembalian dana.');
    } else {
        flash('Gagal membatalkan pesanan');
    }
    admin_go('orders', $back);
}

// ---------- Catat pengembalian dana (wajib unggah bukti) ----------
if (isset($_POST['refund_send'])) {
    $o = row('SELECT * FROM orders WHERE id=?', [(int)$_POST['id']]);

    if (!$o || $o['refund_status'] !== 'Menunggu Pengembalian Dana') {
        flash('Pesanan ini tidak menunggu pengembalian dana');
    } else {
        $img = save_image('refund_proof', 'refunds');
        if (!$img) {
            flash(image_error() ?: 'Unggah foto bukti pengembalian dana');
        } else {
            q("UPDATE orders SET refund_status='Dana Dikembalikan', refund_proof=?, refund_at=NOW() WHERE id=?", [$img, $o['id']]);
            flash('Pengembalian dana dicatat. Menunggu konfirmasi pembeli ✓');
        }
    }
    admin_go('orders', $back);
}

// ---------- Data ----------
$cnt = row("SELECT COUNT(*) AS n,
                   SUM(status <> 'Dibatalkan') AS a,
                   SUM(status = 'Dibatalkan') AS c,
                   SUM(refund_status = 'Menunggu Pengembalian Dana') AS r
            FROM orders");
$chips = [
    'all'    => ['Semua',        (int)$cnt['n']],
    'active' => ['Aktif',        (int)$cnt['a']],
    'cancel' => ['Dibatalkan',   (int)$cnt['c']],
    'refund' => ['Perlu refund', (int)$cnt['r']],
];

$orders = rows('SELECT o.*, u.name AS account FROM orders o JOIN users u ON u.id = o.user_id
                WHERE ' . $where[$f] . ' ORDER BY o.id DESC');

require __DIR__ . '/../layout/header.php';
?>

<?= cx_css() ?>

<div class="cx-chips">
    <?php foreach ($chips as $key => [$label, $n]): ?>
        <a class="cx-chip <?= $f === $key ? 'on' : '' ?>" href="<?= admin_url('orders', $key === 'all' ? [] : ['f' => $key]) ?>"><?= $label ?><em><?= $n ?></em></a>
    <?php endforeach; ?>
</div>

<?php foreach ($orders as $o):
    $cancelled = $o['status'] === 'Dibatalkan';
    $rs        = $o['refund_status'];
    $items     = rows('SELECT oi.*, b.cover, b.id AS bid FROM order_items oi
                       LEFT JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?', [$o['id']]);
?>
    <div class="ao">
        <div class="oh">
            <div><b>#<?= e($o['order_code']) ?></b><small><?= date('d/m/Y H:i', strtotime($o['created_at'])) ?></small></div>

            <?php if ($cancelled): ?>
                <?= order_badge($o) ?>
            <?php else: ?>
                <form method="post">
                    <input type="hidden" name="id" value="<?= $o['id'] ?>">
                    <select class="ss <?= status_class($o['status']) ?>" name="status" onchange="this.form.submit()">
                        <?php foreach ($steps as $s): ?><option <?= $s === $o['status'] ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?>
                    </select>
                </form>
            <?php endif; ?>
        </div>

        <div class="ag">
            <!-- Pesanan -->
            <div>
                <h5>Pesanan</h5>
                <?php foreach ($items as $i): ?>
                    <div class="aoi">
                        <div class="cvw sm"><?= cover(['id' => $i['bid'], 'title' => $i['title'], 'cover' => $i['cover']]) ?></div>
                        <div class="aon"><b><?= e($i['title']) ?></b><small><?= $i['qty'] ?> × <?= rp($i['price']) ?></small></div>
                        <b><?= rp($i['price'] * $i['qty']) ?></b>
                    </div>
                <?php endforeach; ?>
                <div class="atot"><span>Total (termasuk ongkir)</span><b><?= rp($o['total']) ?></b></div>
            </div>

            <!-- Pembeli + pembayaran -->
            <div>
                <h5>Pembeli</h5>
                <div class="abuy">
                    <span class="av"><?= e(mb_strtoupper(mb_substr($o['receiver_name'], 0, 1))) ?></span>
                    <div>
                        <b><?= e($o['receiver_name']) ?></b>
                        <?php if ($o['receiver_name'] !== $o['account']): ?><small>Akun: <?= e($o['account']) ?></small><?php endif; ?>
                    </div>
                </div>
                <div class="ali"><?= icon('phone') ?><span><?= e($o['receiver_phone']) ?></span></div>
                <div class="ali"><?= icon('pin') ?><span><?= e($o['address']) ?></span></div>

                <h5 style="margin-top:22px">Pembayaran & Bukti</h5>
                <div class="apay">
                    <?php if ($o['proof']): ?>
                        <a class="aprf" href="<?= url('uploads/proofs/' . e($o['proof'])) ?>" target="_blank" title="Lihat bukti">
                            <img src="<?= url('uploads/proofs/' . e($o['proof'])) ?>" alt="Bukti"><span>Lihat</span>
                        </a>
                    <?php else: ?>
                        <div class="aprf empty">Belum ada bukti</div>
                    <?php endif; ?>

                    <div class="apm">
                        <b><?= e($o['method']) ?></b>
                        <span class="cat"><?= e($o['provider']) ?></span>
                        <?php if ($o['paid_at']): ?>
                            <span class="st st4"><i class="sd"></i>Bukti diterima</span>
                            <small><?= date('d/m/Y H:i', strtotime($o['paid_at'])) ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>


        <?php /* ============ PESANAN DIBATALKAN ============ */ if ($cancelled): ?>
            <div class="cx-panel">
                <?= cx_banner($o, 'admin') ?>
                <?= cx_tracker($o) ?>

                <?php if ($rs === 'Menunggu Data Rekening'): ?>
                    <div class="cx-box">
                        <h5>Menunggu data dari pembeli</h5>
                        <p class="cx-hint" style="margin:0">Pembeli diminta mengisi tujuan pengembalian dana
                            (<?= e($o['method']) ?> · <?= e($o['provider']) ?>). Tombol pengembalian muncul setelah data diisi.</p>
                    </div>

                <?php elseif ($rs === 'Menunggu Pengembalian Dana'): ?>
                    <div class="cx-box">
                        <h5>Kembalikan dana ke pembeli</h5>
                        <p class="cx-hint">Kirim dana sesuai tujuan di bawah, lalu unggah foto buktinya.</p>
                        <?= refund_dest($o, true) ?>
                        <div class="cx-actions">
                            <button type="button" class="btn" data-dlg="refund-<?= $o['id'] ?>">Kirim Pengembalian Dana</button>
                        </div>
                    </div>

                    <dialog class="cx-dlg" id="refund-<?= $o['id'] ?>">
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $o['id'] ?>">
                            <div class="cx-head">
                                <div><h3>Bukti pengembalian dana</h3><p>#<?= e($o['order_code']) ?> · <?= rp($o['total']) ?></p></div>
                                <button type="button" class="cx-x" data-x aria-label="Tutup">✕</button>
                            </div>
                            <div class="cx-body">
                                <?= refund_dest($o, true) ?>
                                <label class="cx-file" for="rp-<?= $o['id'] ?>">
                                    <?= icon('upload') ?>
                                    <span><b>Pilih foto bukti transfer</b><small>Screenshot atau foto struk pengembalian</small></span>
                                </label>
                                <input type="file" id="rp-<?= $o['id'] ?>" name="refund_proof" accept="image/*" data-fn hidden required>
                            </div>
                            <div class="cx-foot">
                                <button type="button" class="btn o" data-x>Batal</button>
                                <button class="btn" name="refund_send" value="1">Simpan Bukti</button>
                            </div>
                        </form>
                    </dialog>

                <?php elseif ($rs === 'Dana Dikembalikan'): ?>
                    <div class="cx-box">
                        <h5>Menunggu konfirmasi pembeli</h5>
                        <p class="cx-hint">Dana dikirim pada <?= cx_date($o['refund_at']) ?>. Pembeli diminta mengunggah bukti dana yang diterima.</p>
                        <?= refund_dest($o) ?>
                        <div class="cx-proofs">
                            <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" target="_blank">
                                <img src="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" alt=""><span>Bukti dari admin</span>
                            </a>
                        </div>
                    </div>

                <?php else: /* Selesai */ ?>
                    <div class="cx-box ok">
                        <h5>Pengembalian dana selesai</h5>
                        <p class="cx-hint">Dikonfirmasi pembeli pada <?= cx_date($o['refund_confirmed_at']) ?>.</p>
                        <div class="cx-proofs">
                            <?php if ($o['refund_proof']): ?>
                                <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" target="_blank">
                                    <img src="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" alt=""><span>Bukti dari admin</span>
                                </a>
                            <?php endif; ?>
                            <?php if ($o['refund_confirm_proof']): ?>
                                <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_confirm_proof'])) ?>" target="_blank">
                                    <img src="<?= url('uploads/refunds/' . e($o['refund_confirm_proof'])) ?>" alt=""><span>Bukti dari pembeli</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>


        <?php /* ============ BELUM DIBATALKAN: tombol batalkan ============ */ elseif (can_admin_cancel($o)): ?>
            <div class="cx-cancelrow">
                <small>
                    Batalkan pesanan jika ada masalah. Pembeli akan diminta mengisi tujuan pengembalian dana.
                    <?= $o['status'] === 'Dikirim' ? '<b>Buku sudah dikirim, stok tidak dikembalikan otomatis.</b>' : 'Stok buku otomatis dikembalikan.' ?>
                </small>
                <button type="button" class="cx-btn" data-dlg="ac-<?= $o['id'] ?>"><?= cx_icon('x') ?>Batalkan Pesanan</button>
            </div>

            <dialog class="cx-dlg" id="ac-<?= $o['id'] ?>">
                <form method="post">
                    <input type="hidden" name="id" value="<?= $o['id'] ?>">
                    <div class="cx-head">
                        <div><h3>Batalkan pesanan</h3><p>#<?= e($o['order_code']) ?> · <?= e($o['receiver_name']) ?> · <?= rp($o['total']) ?></p></div>
                        <button type="button" class="cx-x" data-x aria-label="Tutup">✕</button>
                    </div>
                    <div class="cx-body">
                        <div class="cx-sec">Alasan pembatalan</div>
                        <div class="cx-reasons">
                            <?php foreach (cancel_reasons('admin') as $r): ?>
                                <label class="cx-r"><input type="radio" name="reason" value="<?= e($r) ?>" required><span><i></i><?= e($r) ?></span></label>
                            <?php endforeach; ?>
                        </div>
                        <label>Catatan untuk pembeli</label>
                        <textarea name="note" rows="2" placeholder="Opsional, wajib diisi jika memilih “Lainnya”"></textarea>
                        <div class="cx-info" style="margin-top:14px">
                            <?= cx_icon('info') ?>
                            <span>Setelah dibatalkan, pembeli mengisi tujuan pengembalian dana sesuai metode bayarnya
                            (<b><?= e($o['method']) ?> · <?= e($o['provider']) ?></b>), lalu kamu mengirim dana dan bukti.</span>
                        </div>
                    </div>
                    <div class="cx-foot">
                        <button type="button" class="btn o" data-x>Tidak jadi</button>
                        <button class="btn cx-danger" name="admin_cancel" value="1">Ya, batalkan pesanan</button>
                    </div>
                </form>
            </dialog>
        <?php endif; ?>
    </div>
<?php endforeach; ?>

<?php if (!$orders): ?>
    <?= empty_state('receipt', $f === 'all' ? 'Belum ada pesanan' : 'Tidak ada pesanan di filter ini',
                    'Pesanan akan muncul di sini setelah pembeli menyelesaikan pembayaran dan mengunggah bukti.',
                    $f === 'all' ? 'Kelola Buku' : 'Tampilkan Semua',
                    $f === 'all' ? admin_url('books') : admin_url('orders')) ?>
<?php endif; ?>

<?= cx_script() ?>

<?php require __DIR__ . '/../layout/footer.php'; ?>