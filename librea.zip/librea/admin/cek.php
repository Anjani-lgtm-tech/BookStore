<?php
// File sementara untuk mengecek isi folder. Hapus setelah selesai.
header('Content-Type: text/plain; charset=utf-8');

$dir = __DIR__ . '/pages';
echo "Folder yang dicari PHP:\n$dir\n\n";

if (!is_dir($dir)) {
    exit("FOLDER TIDAK ADA. Buat folder bernama 'pages' di dalam folder 'admin'.\n");
}

echo "Isi folder (nama persis seperti yang dibaca PHP):\n";
foreach (scandir($dir) as $f) {
    if ($f === '.' || $f === '..') continue;
    echo " - [" . $f . "]\n";
}

echo "\nCek tiap file yang dibutuhkan:\n";
foreach (['books', 'categories', 'users', 'orders', 'reviews', 'messages'] as $p) {
    echo ' - ' . $p . '.php : ' . (file_exists("$dir/$p.php") ? 'ADA' : 'TIDAK ADA') . "\n";
}