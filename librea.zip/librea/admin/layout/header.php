<?php
$counts = [
    'books'      => (int)val('SELECT COUNT(*) FROM books'),
    'categories' => (int)val('SELECT COUNT(*) FROM categories'),
    'users'      => (int)val('SELECT COUNT(*) FROM users'),
    'orders'     => (int)val('SELECT COUNT(*) FROM orders'),
    'reviews'    => (int)val('SELECT COUNT(*) FROM reviews'),
    'messages'   => (int)val('SELECT COUNT(*) FROM messages'),
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> — Admin Libréa</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php foreach (['base', 'layout', 'components', 'pages', 'admin'] as $css): ?>
        <link rel="stylesheet" href="<?= url("assets/css/$css.css") ?>">
    <?php endforeach; ?>
    <link rel="stylesheet" href="<?= url('assets/css/empty.css') ?>">
</head>
<body>

<nav>
    <a class="logo" href="<?= admin_url('books') ?>">
        <?= brand_icon() ?>
        <span class="lt">Libréa</span>
        <span class="adm-tag">ADMIN</span>
    </a>
    <a class="nlogin" href="<?= action('logout') ?>">Keluar</a>
</nav>

<?php if ($f = flash()): ?><div class="toast"><?= e($f) ?></div><?php endif; ?>

<main>
<div class="adm">

    <aside class="side">
        <div class="pwho">
            <?= avatar(user(), 'big') ?>
            <b>Admin Libréa</b>
            <span>Dashboard</span>
        </div>
        <?php foreach ($menu as $key => [$label, $ic]): ?>
            <a class="si <?= $current === $key ? 'on' : '' ?>" href="<?= admin_url($key) ?>">
                <?= icon($ic) ?><?= $label ?><em><?= $counts[$key] ?></em>
            </a>
        <?php endforeach; ?>
    </aside>

    <section class="content">
        <h2 class="t"><?= e($title) ?></h2>