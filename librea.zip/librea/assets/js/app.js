// ==========================================================================
// app.js
// --------------------------------------------------------------------------
// 1. Dropdown kategori        4. Popup (dialog)
// 2. Keranjang: total         5. Notifikasi & badge keranjang
// 3. Pratinjau foto           6. Keranjang tanpa pindah halaman (AJAX)
// ==========================================================================


// 1. DROPDOWN KATEGORI — tutup saat klik di luar
// --------------------------------------------------------------------------
document.addEventListener('click', e => {
  document.querySelectorAll('details.ndd[open]').forEach(d => {
    if (!d.contains(e.target)) d.removeAttribute('open');
  });
});


// 2. KERANJANG — pilih semua + total barang yang dicentang
// --------------------------------------------------------------------------
const all   = document.getElementById('all');
const boxes = () => document.querySelectorAll('input[name="sel[]"]');
const rupiah = n => 'Rp' + Number(n).toLocaleString('id-ID');

function calc() {
  let total = 0, count = 0;
  boxes().forEach(i => { if (i.checked) { total += +i.dataset.sub; count++; } });

  const T = document.getElementById('tot'), C = document.getElementById('cnt');
  if (T) T.textContent = rupiah(total);
  if (C) C.textContent = count;
  if (all) all.checked = count === boxes().length && count > 0;
}

if (all) all.addEventListener('change', () => { boxes().forEach(i => i.checked = all.checked); calc(); });
boxes().forEach(i => i.addEventListener('change', calc));
calc();


// 3. PRATINJAU FOTO sebelum diunggah
// --------------------------------------------------------------------------
document.querySelectorAll('input[type=file][data-preview]').forEach(input => {
  input.addEventListener('change', () => {
    const file = input.files[0], box = document.getElementById(input.dataset.preview);
    if (file && box) box.innerHTML = '<img src="' + URL.createObjectURL(file) + '" alt="">';
  });
});


// 4. POPUP (dialog) — buka: data-open="id" · tutup: data-close, Esc, atau klik area gelap
// --------------------------------------------------------------------------
document.querySelectorAll('[data-open]').forEach(btn => {
  btn.addEventListener('click', e => {
    e.preventDefault();
    const dialog = document.getElementById(btn.dataset.open);
    if (dialog) dialog.showModal();
  });
});

document.querySelectorAll('dialog.modal').forEach(dialog => {
  dialog.querySelectorAll('[data-close]').forEach(btn => btn.addEventListener('click', () => dialog.close()));
  dialog.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
});


// 5. NOTIFIKASI & BADGE KERANJANG
// --------------------------------------------------------------------------
function showToast(msg) {
  const old = document.getElementById('js-toast');
  if (old) old.remove();

  const t = document.createElement('div');
  t.id = 'js-toast';
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

function setCartBadge(count) {
  const nic = document.querySelector('.nic');
  if (!nic) return;

  let badge = nic.querySelector('.badge');
  if (count > 0) {
    if (!badge) {
      badge = document.createElement('span');
      badge.className = 'badge';
      nic.appendChild(badge);
    }
    badge.textContent = count;
  } else if (badge) {
    badge.remove();
  }
}


// 6. KERANJANG TANPA PINDAH HALAMAN (AJAX)
// --------------------------------------------------------------------------
async function postCart(url, formData) {
  const res  = await fetch(url, { method: 'POST', body: formData, headers: { 'X-Requested-With': 'fetch' } });
  const data = await res.json();
  if (data.login) { location.href = data.login; return null; }   // belum masuk → ke halaman login
  return data;
}

// a) tombol "+ Keranjang" di kartu buku
document.querySelectorAll('form[data-cart]').forEach(form => {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const btn = form.querySelector('button');
    if (btn) btn.disabled = true;

    try {
      const data = await postCart(form.action, new FormData(form));
      if (!data) return;
      showToast(data.msg || 'Selesai');
      if (typeof data.count === 'number') setCartBadge(data.count);
    } catch (err) {
      form.submit();                                              // cadangan: kirim biasa
    } finally {
      if (btn) btn.disabled = false;
    }
  });
});

// b) tombol jumlah + / − di halaman keranjang
document.querySelectorAll('form[data-qty]').forEach(form => {
  const buttons = form.querySelectorAll('button');

  buttons.forEach(btn => btn.addEventListener('click', async e => {
    e.preventDefault();
    const fd = new FormData(form);
    fd.set('d', btn.value);
    buttons.forEach(b => b.disabled = true);

    try {
      const data = await postCart(form.action, fd);
      if (!data) return;

      if (typeof data.qty === 'number') {
        const item = form.closest('.citem');
        form.querySelector('span').textContent = data.qty;
        item.querySelector('.csub').textContent = rupiah(data.sub);
        const box = item.querySelector('input[name="sel[]"]');
        if (box) box.dataset.sub = data.sub;
        calc();                                                   // total di bar bawah ikut berubah
      }
      if (data.msg) showToast(data.msg);
      if (typeof data.count === 'number') setCartBadge(data.count);
    } catch (err) {
      location.reload();
    } finally {
      buttons.forEach(b => b.disabled = false);
    }
  }));
});

// c) tombol "Hapus" di halaman keranjang
document.querySelectorAll('form[data-remove]').forEach(form => {
  form.addEventListener('submit', async e => {
    e.preventDefault();
    try {
      const data = await postCart(form.action, new FormData(form));
      if (!data) return;

      form.closest('.citem').remove();
      const left = document.querySelectorAll('.citem').length;
      if (left === 0) { location.reload(); return; }              // keranjang kosong → tampilkan halaman kosong

      const cc = document.getElementById('ccount');
      if (cc) cc.textContent = left;
      calc();
      if (typeof data.count === 'number') setCartBadge(data.count);
      showToast('Dihapus dari keranjang');
    } catch (err) {
      location.reload();
    }
  });
});