<?php
$id = (int)($_GET['id'] ?? 0);
$b  = row("SELECT b.*, c.name AS cat_name, c.icon AS cat_icon,
                  (SELECT ROUND(AVG(rating),1) FROM reviews WHERE book_id = b.id) AS rating,
                  (SELECT COUNT(*)            FROM reviews WHERE book_id = b.id) AS rev
           FROM books b JOIN categories c ON c.id = b.category_id WHERE b.id = ?", [$id]);
if (!$b) go('home');

$u       = user();
$wish    = $u ? (bool)val('SELECT 1 FROM wishlist WHERE user_id=? AND book_id=?', [$u['id'], $id]) : false;
$reviews = rows('SELECT r.*, u.name, u.photo FROM reviews r JOIN users u ON u.id = r.user_id
                 WHERE r.book_id = ? ORDER BY r.id DESC', [$id]);
$inStock = $b['stock'] > 0;
$title   = $b['title'] . ' — Libréa';

$specs = [
    ['Penerbit',       $b['publisher'] ?: '-',                        'book'],
    ['Tahun Terbit',   $b['year'] ?: '-',                             'cal'],
    ['Jumlah Halaman', $b['pages'] ? $b['pages'] . ' halaman' : '-', 'receipt'],
    ['ISBN',           $b['isbn'] ?: '-',                             'tag'],
    ['Kategori',       $b['cat_name'],                                $b['cat_icon']],
];

require ROOT . '/views/header.php';
?>

<a class="back" href="<?= route('home') ?>">← Kembali ke katalog</a>

<div class="box dt">

    <!-- KOLOM KIRI: sampul + pembelian -->
    <form class="dl" method="post" action="<?= action('cart') ?>">
        <?= cover($b) ?>
        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
        <?= back_input() ?>

        <div class="buy">
            <div class="qrow">
                <b>Jumlah</b>
                <div class="stepper">
                    <button type="button" data-step="-1">−</button>
                    <input type="number" name="qty" value="1" min="1" max="<?= max(1, $b['stock']) ?>" readonly>
                    <button type="button" data-step="1">+</button>
                </div>
            </div>
            <div class="bts">
                <button class="btn" name="buy" value="1" formaction="<?= route('checkout') ?>" <?= $inStock ? '' : 'disabled' ?>>Beli Sekarang</button>
                <button class="btn pk" name="op" value="add" <?= $inStock ? '' : 'disabled' ?>>Tambah ke Keranjang</button>
            </div>
        </div>
    </form>

    <!-- KOLOM KANAN: informasi -->
    <div class="dr">
        <form class="wish" method="post" action="<?= action('wishlist') ?>">
            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
            <?= back_input() ?>
            <button class="heart <?= $wish ? 'on' : '' ?>" title="Wishlist"><?= icon('heart') ?></button>
        </form>

        <span class="dcat"><?= icon($b['cat_icon']) ?><?= e($b['cat_name']) ?></span>
        <h1><?= e($b['title']) ?></h1>
        <div class="au"><?= e($b['author']) ?></div>

        <div class="rt">
            <?php if ($b['rev']): ?>
                <b><?= $b['rating'] ?></b><?= stars($b['rating']) ?><small>(<?= $b['rev'] ?> ulasan)</small>
            <?php else: ?>
                <small>Belum ada ulasan</small>
            <?php endif; ?>
        </div>

        <div class="dprice">
            <div class="dp"><?= rp($b['price']) ?></div>
            <div class="stk <?= $inStock ? '' : 'no' ?>"><i></i><?= $inStock ? 'Stok tersedia · ' . $b['stock'] . ' buku' : 'Stok habis' ?></div>
        </div>

        <div class="dh">Deskripsi</div>
        <p class="dd"><?= nl2br(e($b['description'])) ?></p>

        <div class="dh">Informasi Buku</div>
        <div class="specs">
            <?php foreach ($specs as [$label, $value, $ic]): ?>
                <div class="spec">
                    <div class="ico"><?= icon($ic) ?></div>
                    <div><small><?= $label ?></small><b><?= e($value) ?></b></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="dh">Ulasan Pembeli</div>
        <?php if ($reviews): ?>
            <div class="rsum">
                <b><?= $b['rating'] ?></b>
                <div><?= stars($b['rating']) ?><small style="display:block">dari <?= $b['rev'] ?> ulasan</small></div>
            </div>
        <?php endif; ?>
        <?php foreach ($reviews as $r): ?>
            <div class="rv">
                <?= avatar($r) ?>
                <div>
                    <b><?= e($r['name']) ?></b> <?= stars($r['rating']) ?>
                    <small><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></small>
                    <?php if ($r['comment']): ?><p><?= nl2br(e($r['comment'])) ?></p><?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
        <?php if (!$reviews): ?><p class="dd">Belum ada ulasan. Jadilah yang pertama setelah membeli buku ini.</p><?php endif; ?>
    </div>
</div>

<script>
document.querySelectorAll('.stepper').forEach(box => {
    const input = box.querySelector('input');
    box.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => {
        input.value = Math.max(+input.min, Math.min(+input.max, (+input.value) + (+btn.dataset.step)));
    }));
});
</script>

<?php require ROOT . '/views/footer.php'; ?>