<?php
$title = 'Libréa — Toko Buku Online';

// ---------- Data ----------
$cat = (int)($_GET['cat'] ?? 0);
$kw  = trim($_GET['q'] ?? '');

$sql  = "SELECT b.*, c.name AS cat_name,
                (SELECT ROUND(AVG(rating),1) FROM reviews WHERE book_id = b.id) AS rating,
                (SELECT COUNT(*)            FROM reviews WHERE book_id = b.id) AS rev
         FROM books b JOIN categories c ON c.id = b.category_id
         WHERE (b.title LIKE ? OR b.author LIKE ? OR c.name LIKE ?)";
$args = ["%$kw%", "%$kw%", "%$kw%"];
if ($cat) { $sql .= ' AND b.category_id = ?'; $args[] = $cat; }

$books = rows($sql . ' ORDER BY b.id DESC', $args);

require ROOT . '/views/header.php';
?>

<section class="hero">
    <div>
        <h1>Temukan dunia baru di setiap <em>halaman</em></h1>
        <p>Libréa menghadirkan koleksi buku pilihan dengan nuansa hangat dan modern. Cari, simpan ke keranjang, dan bacaan favoritmu segera meluncur.</p>

        <form class="search" method="get" action="<?= url('index.php') ?>">
            <input type="hidden" name="page" value="home">
            <?php if ($cat): ?><input type="hidden" name="cat" value="<?= $cat ?>"><?php endif; ?>
            <input name="q" placeholder="Cari judul, penulis, atau kategori…" value="<?= e($kw) ?>">
            <button class="btn">Cari</button>
        </form>
    </div>

    <div class="stack">
        <div class="bk" style="--r:rotate(-8deg); left:5%;  top:30px"><?= img_slot('hero1') ?></div>
        <div class="bk" style="--r:rotate(0deg);  left:32%; top:0; z-index:2"><?= img_slot('hero2') ?></div>
        <div class="bk" style="--r:rotate(9deg);  left:58%; top:40px"><?= img_slot('hero3') ?></div>
    </div>
</section>

<div class="rsl" id="kat">
    <?php if ($cat || $kw !== ''): ?>
        <a href="<?= route('home') ?>#kat">← Tampilkan semua buku</a>
    <?php endif; ?>
</div>

<div class="grid">
    <?php foreach ($books as $b): ?>
        <div class="card">
            <a href="<?= route('book', ['id' => $b['id']]) ?>">
                <?= cover($b) ?>
                <h3><?= e($b['title']) ?></h3>
                <div class="a"><?= e($b['author']) ?></div>
                <span class="tag"><?= e($b['cat_name']) ?></span>
            </a>

            <div class="pr">
                <span><?= rp($b['price']) ?></span>
                <?php if ($b['rev']): ?>
                    <span class="rt2"><?= icon('star') ?><?= $b['rating'] ?></span>
                <?php else: ?>
                    <span class="rt2 nw">Baru</span>
                <?php endif; ?>
            </div>

            <?php if ($b['stock'] > 0): ?>
                <div class="card-btns">
                    <!-- tambah ke keranjang tanpa pindah halaman (data-cart → ditangani app.js) -->
                    <form method="post" action="<?= action('cart') ?>" data-cart>
                        <input type="hidden" name="op" value="add">
                        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                        <button class="btn s">+ Keranjang</button>
                    </form>

                    <!-- beli langsung (tidak lewat keranjang) -->
                    <form method="post" action="<?= route('checkout') ?>">
                        <input type="hidden" name="buy" value="1">
                        <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                        <input type="hidden" name="qty" value="1">
                        <button class="btn s pk">Beli Sekarang</button>
                    </form>
                </div>
            <?php else: ?>
                <button class="btn s" disabled>Stok habis</button>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <?php if (!$books): ?><p>Buku tidak ditemukan 😢</p><?php endif; ?>
</div>

<?php require ROOT . '/views/footer.php'; ?>