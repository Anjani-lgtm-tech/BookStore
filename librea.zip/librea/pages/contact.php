<?php
$title = 'Kontak — Libréa';
$u = user();

// ---------- Kirim pesan ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    need_login();
    $subject = trim($_POST['subject'] ?? '');
    $body    = trim($_POST['body'] ?? '');

    if ($subject === '' || $body === '') {
        flash('Lengkapi subjek dan pesan');
    } else {
        q('INSERT INTO messages (user_id, subject, body) VALUES (?,?,?)', [$u['id'], $subject, $body]);
        flash('Pesan terkirim ke admin ✓');
    }
    go('contact');
}

require ROOT . '/views/header.php';
?>

<div class="box narrow">
    <h2 class="t">Hubungi Admin</h2>

    <?php if ($u): ?>
        <form method="post">
            <label>Subjek</label>
            <input name="subject" required>
            <label>Pesan</label>
            <textarea name="body" rows="5" required></textarea>
            <br><br>
            <button class="btn">Kirim Pesan</button>
        </form>
    <?php else: ?>
        <p>Silakan masuk untuk mengirim pesan ke admin.</p>
        <a class="btn" href="<?= route('login') ?>">Masuk</a>
    <?php endif; ?>
</div>

<?php require ROOT . '/views/footer.php'; ?>