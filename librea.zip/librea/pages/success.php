<?php
need_login();
$u     = user();
$title = 'Pembayaran Berhasil — Libréa';

$o = row('SELECT * FROM orders WHERE order_code=? AND user_id=?', [$_GET['code'] ?? '', $u['id']]);
if (!$o) go('home');

$items = rows('SELECT oi.*, b.cover, b.id AS bid FROM order_items oi
               LEFT JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?', [$o['id']]);

// subtotal buku & ongkir (selisih dari total pesanan)
$subtotal = 0;
foreach ($items as $i) $subtotal += $i['price'] * $i['qty'];
$shipping = max(0, (int)$o['total'] - $subtotal);

require ROOT . '/views/header.php';
?>

<div class="box sux">
    <div class="okc"><?= icon('check') ?></div>
    <h1>Pembayaran Berhasil!</h1>
    <p class="sxp">Terima kasih, pesananmu telah berhasil dibayar.<br>Bukti pembayaran sudah dikirim ke admin untuk dikonfirmasi.</p>

    <div class="sinfo">
        <div class="sit"><div class="ico"><?= icon('receipt') ?></div><div><small>Nomor Pesanan</small><b>#<?= e($o['order_code']) ?></b></div></div>
        <div class="sit"><div class="ico"><?= icon('cal') ?></div><div><small>Tanggal Pembayaran</small><b><?= date('d/m/Y H:i', strtotime($o['paid_at'])) ?></b></div></div>
        <div class="sit"><div class="ico"><?= icon('cart') ?></div><div><small>Metode Pembayaran</small><b><?= e($o['method']) ?> · <?= e($o['provider']) ?></b></div></div>
        <div class="sit"><div class="ico"><?= icon('check') ?></div><div><small>Status Pembayaran</small><span class="st <?= status_class($o['status']) ?>"><?= e($o['status']) ?></span></div></div>
    </div>

    <h3 class="sxt">Rincian Pesanan</h3>
    <div class="scroll">
        <div class="sxh"><span>Produk</span><span>Harga</span><span>Jumlah</span><span>Subtotal</span></div>
        <?php foreach ($items as $i): ?>
            <div class="sxr">
                <div class="bt">
                    <div class="cvw sm"><?= cover(['id' => $i['bid'], 'title' => $i['title'], 'cover' => $i['cover']]) ?></div>
                    <b><?= e($i['title']) ?></b>
                </div>
                <span><?= rp($i['price']) ?></span>
                <span><?= $i['qty'] ?></span>
                <b><?= rp($i['price'] * $i['qty']) ?></b>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="sxs"><span>Subtotal</span><span><?= rp($subtotal) ?></span></div>
    <div class="sxs"><span>Ongkos kirim</span><span><?= $shipping > 0 ? rp($shipping) : '-' ?></span></div>
    <div class="sxs tot"><span>Total Pembayaran</span><span><?= rp($o['total']) ?></span></div>

    <div class="sxb">
        <a class="btn" href="<?= route('home') ?>">Kembali ke Beranda</a>
        <a class="btn o" href="<?= route('profile', ['tab' => 'pesanan']) ?>">Lihat Pesanan Saya</a>
    </div>
</div>

<?php require ROOT . '/views/footer.php'; ?>