<?php
need_login();
$u = user();
if ($u['role'] === 'admin') redirect(url('admin/'));
$title = 'Akun Saya — Libréa';

// ---------- Simpan perubahan profil ----------
if (isset($_POST['edit'])) {
    $photo = save_image('photo', 'avatars');
    $args  = [trim($_POST['name']) ?: $u['name'], trim($_POST['phone']), trim($_POST['address'])];
    if ($photo) $args[] = $photo;
    $args[] = $u['id'];

    q('UPDATE users SET name=?, phone=?, address=?' . ($photo ? ', photo=?' : '') . ' WHERE id=?', $args);
    flash(!$photo && image_error() !== '' ? 'Profil diperbarui, tetapi foto gagal: ' . image_error() : 'Profil diperbarui ✓');
    go('profile');
}

// ---------- Menu ----------
$tab  = $_GET['tab'] ?? 'akun';
$menu = [
    'akun'     => ['Akun Saya',     'user'],
    'pesanan'  => ['Pesanan Saya',  'cart'],
    'wishlist' => ['Wishlist Saya', 'heart'],
    'pesan'    => ['Pesan Saya',    'mail'],
];
if (!isset($menu[$tab])) $tab = 'akun';

require ROOT . '/views/header.php';
?>

<div class="adm">
    <aside class="side">
        <div class="pwho">
            <?= avatar($u, 'big') ?>
            <b><?= e($u['name']) ?></b>
            <span><?= e($u['email']) ?></span>
        </div>

        <a class="si" href="<?= route('home') ?>"><?= icon('home') ?>Beranda</a>
        <?php foreach ($menu as $key => [$label, $ic]): ?>
            <a class="si <?= $tab === $key ? 'on' : '' ?>" href="<?= route('profile', ['tab' => $key]) ?>"><?= icon($ic) ?><?= $label ?></a>
        <?php endforeach; ?>
        <div class="sep"></div>
        <a class="si" href="<?= action('logout') ?>"><?= icon('out') ?>Keluar</a>
    </aside>

    <section>
        <h2 class="t"><?= $menu[$tab][0] ?></h2>

<?php /* ============================ AKUN ============================ */ if ($tab === 'akun'):
    $nOrders  = (int)val('SELECT COUNT(*) FROM orders   WHERE user_id=?', [$u['id']]);
    $nWish    = (int)val('SELECT COUNT(*) FROM wishlist WHERE user_id=?', [$u['id']]);
    $nReviews = (int)val('SELECT COUNT(*) FROM reviews  WHERE user_id=?', [$u['id']]);
    $info = [
        ['Nama Lengkap',      $u['name'],                                 'user'],
        ['Email',             $u['email'],                                'mail'],
        ['No. Telepon',       $u['phone'],                                'phone'],
        ['Tanggal Bergabung', date('d/m/Y', strtotime($u['created_at'])), 'cal'],
        ['Alamat',            $u['address'],                              'pin'],
    ];
?>
        <p class="sub">Kelola informasi pribadi anda.</p>

        <div class="phero">
            <div class="pcover"></div>
            <div class="pbody">
                <?= avatar($u, 'big') ?>
                <div class="pmeta"><b><?= e($u['name']) ?></b><small><?= e($u['email']) ?></small></div>
                <button type="button" class="btn s" data-popup="dlg-edit">Edit Profil</button>
            </div>
            <div class="pstats">
                <div><b><?= $nOrders ?></b><span>Pesanan</span></div>
                <div><b><?= $nWish ?></b><span>Wishlist</span></div>
                <div><b><?= $nReviews ?></b><span>Ulasan</span></div>
            </div>
        </div>

        <div class="igrid">
            <?php foreach ($info as [$label, $value, $ic]): ?>
                <div class="icard <?= $label === 'Alamat' ? 'wide' : '' ?>">
                    <div class="ico"><?= icon($ic) ?></div>
                    <div>
                        <small><?= $label ?></small>
                        <?= $value
                            ? '<b>' . e($value) . '</b>'
                            : '<b class="mt">Belum diisi · <a href="#" data-popup="dlg-edit">Lengkapi</a></b>' ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- POPUP EDIT PROFIL -->
        <dialog class="modal" id="dlg-edit">
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="edit" value="1">

                <div class="modal-head">
                    <div>
                        <h3>Edit Profil</h3>
                        <p>Perbarui foto dan informasi pribadimu.</p>
                    </div>
                    <button type="button" class="modal-x" data-close aria-label="Tutup">✕</button>
                </div>

                <div class="modal-body">
                    <div class="modal-photo">
                        <div class="pv round" id="pvp">
                            <?= $u['photo'] ? '<img src="' . url('uploads/avatars/' . e($u['photo'])) . '" alt="">' : '<span>Belum ada foto</span>' ?>
                        </div>
                        <div>
                            <b>Foto profil</b>
                            <small>JPG, PNG, WEBP, GIF, dan format lain · maks. 20 MB</small>
                            <label class="btn o s" for="photo-input" style="display:inline-block; margin:0; cursor:pointer">Pilih foto</label>
                            <input type="file" id="photo-input" name="photo" accept="image/*" data-preview="pvp" hidden>
                        </div>
                    </div>

                    <label>Nama lengkap</label>
                    <input name="name" value="<?= e($u['name']) ?>" required>

                    <label>No. Telepon</label>
                    <input name="phone" value="<?= e($u['phone']) ?>" placeholder="08xxxxxxxxxx">

                    <label>Alamat lengkap</label>
                    <textarea name="address" rows="3" placeholder="Jalan, nomor, kota, kode pos"><?= e($u['address']) ?></textarea>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn o" data-close>Batal</button>
                    <button class="btn">Simpan</button>
                </div>
            </form>
        </dialog>

        <script>
        // buka / tutup popup edit profil
        (function () {
            var dlg = document.getElementById('dlg-edit');
            if (!dlg) return;

            document.querySelectorAll('[data-popup="dlg-edit"]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    dlg.showModal();
                });
            });
            dlg.querySelectorAll('[data-close]').forEach(function (btn) {
                btn.addEventListener('click', function () { dlg.close(); });
            });
            dlg.addEventListener('click', function (e) {
                if (e.target === dlg) dlg.close();     // klik area gelap
            });
        })();
        </script>

<?php /* =========================== PESANAN =========================== */ elseif ($tab === 'pesanan'):
    $orders = rows('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC', [$u['id']]);
    $steps  = ['Menunggu Pembayaran', 'Dibayar', 'Dikirim', 'Selesai'];
?>
        <?= cx_css() ?>
        <p class="sub">Pantau status pesanan bukumu.</p>

        <?php foreach ($orders as $o):
            $cancelled = $o['status'] === 'Dibatalkan';
            $idx       = array_search($o['status'], $steps);
            $items     = rows('SELECT oi.*, b.cover, b.author, b.id AS bid,
                                      (SELECT id FROM reviews r WHERE r.order_id = oi.order_id AND r.book_id = oi.book_id) AS review_id
                               FROM order_items oi LEFT JOIN books b ON b.id = oi.book_id WHERE oi.order_id = ?', [$o['id']]);
        ?>
            <div class="oc">
                <div class="oh">
                    <div><b>#<?= e($o['order_code']) ?></b><small><?= date('d/m/Y H:i', strtotime($o['created_at'])) ?></small></div>
                    <?= order_badge($o) ?>
                </div>

                <?php foreach ($items as $i): ?>
                    <div class="oi">
                        <div class="cvw sm"><?= cover(['id' => $i['bid'], 'title' => $i['title'], 'author' => $i['author'], 'cover' => $i['cover']]) ?></div>
                        <div style="flex:1">
                            <b><?= e($i['title']) ?></b>
                            <small>Jumlah: <?= $i['qty'] ?> · <?= rp($i['price']) ?></small>

                            <?php if ($o['status'] === 'Selesai' && $i['bid']): ?>
                                <?php if ($i['review_id']): ?>
                                    <span class="st st1">★ Sudah diulas</span>
                                <?php else: ?>
                                    <details class="rvf">
                                        <summary class="btn s">Beri Ulasan</summary>
                                        <form method="post" action="<?= action('review') ?>">
                                            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                            <input type="hidden" name="book_id" value="<?= $i['bid'] ?>">
                                            <div class="rate">
                                                <?php for ($s = 5; $s >= 1; $s--): $rid = "r{$o['id']}_{$i['bid']}_$s"; ?>
                                                    <input type="radio" name="rating" id="<?= $rid ?>" value="<?= $s ?>" required>
                                                    <label for="<?= $rid ?>">★</label>
                                                <?php endfor; ?>
                                            </div>
                                            <textarea name="comment" rows="3" placeholder="Ceritakan pengalamanmu membaca buku ini…"></textarea>
                                            <button class="btn s">Kirim Ulasan</button>
                                        </form>
                                    </details>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <?php if (!$cancelled): ?>
                    <div class="trk">
                        <?php foreach ($steps as $n => $s): ?>
                            <div class="tk <?= $n <= $idx ? 'dn' : '' ?>"><i></i><?= $s === 'Menunggu Pembayaran' ? 'Menunggu' : $s ?></div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <div class="of">
                    <div><small>Pembayaran</small><b><?= e($o['method']) ?> · <?= e($o['provider']) ?></b></div>
                    <div><small>Penerima & Alamat</small><b><?= e($o['receiver_name']) ?> · <?= e($o['receiver_phone']) ?><br><?= e($o['address']) ?></b></div>
                    <div class="tt"><small>Total</small><b><?= rp($o['total']) ?></b></div>
                </div>


                <?php /* ============ PESANAN DIBATALKAN: keterangan + pengembalian dana ============ */ if ($cancelled):
                    $rs = $o['refund_status'];
                ?>
                    <div class="cx-panel">
                        <?= cx_banner($o, 'user') ?>
                        <?= cx_tracker($o) ?>

                        <?php if ($rs === 'Menunggu Data Rekening'): ?>
                            <div class="cx-box">
                                <h5>Isi tujuan pengembalian dana</h5>
                                <p class="cx-hint">
                                    Dana <b><?= rp($o['total']) ?></b> akan dikembalikan sesuai metode pembayaranmu
                                    (<b><?= e($o['method']) ?> · <?= e($o['provider']) ?></b>).
                                </p>
                                <form method="post" action="<?= action('cancel') ?>">
                                    <input type="hidden" name="op" value="account">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <?= refund_fields($o) ?>
                                    <div class="cx-actions"><button class="btn">Kirim Data Pengembalian Dana</button></div>
                                </form>
                            </div>

                        <?php elseif ($rs === 'Menunggu Pengembalian Dana'): ?>
                            <div class="cx-box">
                                <h5>Pengembalian dana sedang diproses</h5>
                                <p class="cx-hint">Admin akan mengirim dana ke tujuan di bawah. Setelah dana masuk, kamu diminta mengonfirmasi dengan foto bukti.</p>
                                <?= refund_dest($o) ?>
                            </div>

                        <?php elseif ($rs === 'Dana Dikembalikan'): ?>
                            <div class="cx-box">
                                <h5>Dana sudah dikembalikan admin</h5>
                                <p class="cx-hint">Dikirim pada <?= cx_date($o['refund_at']) ?>. Cek saldomu, lalu konfirmasi dengan mengunggah foto bukti dana yang kamu terima.</p>
                                <?= refund_dest($o) ?>

                                <?php if ($o['refund_proof']): ?>
                                    <div class="cx-proofs">
                                        <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" target="_blank">
                                            <img src="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" alt=""><span>Bukti dari admin</span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <form method="post" action="<?= action('cancel') ?>" enctype="multipart/form-data">
                                    <input type="hidden" name="op" value="confirm">
                                    <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                    <label class="cx-file" for="cf-<?= $o['id'] ?>">
                                        <?= icon('upload') ?>
                                        <span><b>Pilih foto bukti dana diterima</b><small>Screenshot saldo atau mutasi rekening</small></span>
                                    </label>
                                    <input type="file" id="cf-<?= $o['id'] ?>" name="proof" accept="image/*" data-fn hidden required>
                                    <div class="cx-actions"><button class="btn">Konfirmasi Dana Diterima</button></div>
                                </form>
                            </div>

                        <?php else: /* Selesai */ ?>
                            <div class="cx-box ok">
                                <h5>Pengembalian dana selesai</h5>
                                <p class="cx-hint">Dana <?= rp($o['total']) ?> sudah kembali ke <?= e($o['refund_method']) ?>. Dikonfirmasi pada <?= cx_date($o['refund_confirmed_at']) ?>.</p>
                                <div class="cx-proofs">
                                    <?php if ($o['refund_proof']): ?>
                                        <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" target="_blank">
                                            <img src="<?= url('uploads/refunds/' . e($o['refund_proof'])) ?>" alt=""><span>Bukti dari admin</span>
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($o['refund_confirm_proof']): ?>
                                        <a class="cx-proof" href="<?= url('uploads/refunds/' . e($o['refund_confirm_proof'])) ?>" target="_blank">
                                            <img src="<?= url('uploads/refunds/' . e($o['refund_confirm_proof'])) ?>" alt=""><span>Bukti darimu</span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>


                <?php /* ============ BELUM DIPROSES: tombol batalkan ============ */ elseif (can_user_cancel($o)): ?>
                    <div class="cx-cancelrow">
                        <small>Pesananmu belum diproses, jadi kamu masih bisa membatalkannya.</small>
                        <button type="button" class="cx-btn" data-dlg="cancel-<?= $o['id'] ?>"><?= cx_icon('x') ?>Batalkan Pesanan</button>
                    </div>

                    <dialog class="cx-dlg" id="cancel-<?= $o['id'] ?>">
                        <form method="post" action="<?= action('cancel') ?>">
                            <input type="hidden" name="op" value="cancel">
                            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">

                            <div class="cx-head">
                                <div><h3>Batalkan pesanan</h3><p>#<?= e($o['order_code']) ?> · <?= rp($o['total']) ?></p></div>
                                <button type="button" class="cx-x" data-x aria-label="Tutup">✕</button>
                            </div>

                            <div class="cx-body">
                                <div class="cx-sec">Alasan pembatalan</div>
                                <div class="cx-reasons">
                                    <?php foreach (cancel_reasons('user') as $r): ?>
                                        <label class="cx-r"><input type="radio" name="reason" value="<?= e($r) ?>" required><span><i></i><?= e($r) ?></span></label>
                                    <?php endforeach; ?>
                                </div>
                                <label>Catatan tambahan</label>
                                <textarea name="note" rows="2" placeholder="Opsional, wajib diisi jika memilih “Lainnya”"></textarea>

                                <div class="cx-sec">Pengembalian dana</div>
                                <div class="cx-info">
                                    <?= cx_icon('info') ?>
                                    <span>Dana <b><?= rp($o['total']) ?></b> (termasuk ongkir) dikembalikan sesuai metode pembayaranmu:
                                    <b><?= e($o['method']) ?> · <?= e($o['provider']) ?></b>.</span>
                                </div>
                                <?= refund_fields($o) ?>
                            </div>

                            <div class="cx-foot">
                                <button type="button" class="btn o" data-x>Tidak jadi</button>
                                <button class="btn cx-danger">Ya, batalkan pesanan</button>
                            </div>
                        </form>
                    </dialog>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <?php if (!$orders): ?>
            <?= empty_state('receipt', 'Belum ada pesanan', 'Pesanan yang kamu buat akan muncul di sini, lengkap dengan status pengirimannya.', 'Mulai Belanja', route('home')) ?>
        <?php endif; ?>

        <?= cx_script() ?>

<?php /* =========================== WISHLIST =========================== */ elseif ($tab === 'wishlist'):
    $wishes = rows('SELECT b.* FROM wishlist w JOIN books b ON b.id = w.book_id WHERE w.user_id=? ORDER BY b.title', [$u['id']]);
?>
        <p class="sub">Buku-buku yang kamu simpan.</p>

        <?php if ($wishes): ?>
            <div class="box">
                <?php foreach ($wishes as $b): ?>
                    <div class="row">
                        <a class="cvw sm" href="<?= route('book', ['id' => $b['id']]) ?>"><?= cover($b) ?></a>
                        <div style="flex:1">
                            <b><?= e($b['title']) ?></b>
                            <div class="a"><?= e($b['author']) ?></div>
                            <b style="color:var(--pink)"><?= rp($b['price']) ?></b>
                        </div>
                        <form method="post" action="<?= action('wishlist') ?>">
                            <input type="hidden" name="book_id" value="<?= $b['id'] ?>">
                            <input type="hidden" name="back" value="page=profile&tab=wishlist">
                            <button class="btn d s">Hapus</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <?= empty_state('heart', 'Wishlist masih kosong', 'Tekan ikon hati di halaman buku untuk menyimpan buku favoritmu di sini.', 'Jelajahi Buku', route('home')) ?>
        <?php endif; ?>

<?php /* ============================= PESAN ============================= */ else:
    $msgs = rows('SELECT * FROM messages WHERE user_id=? ORDER BY id DESC', [$u['id']]);
?>
        <p class="sub">Pesan yang kamu kirim ke admin dan balasannya.</p>

        <?php foreach ($msgs as $m): ?>
            <div class="mc" style="display:block">
                <div class="mh2"><b><?= e($m['subject']) ?></b><small><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></small></div>
                <p><?= nl2br(e($m['body'])) ?></p>
                <?php if ($m['reply']): ?>
                    <div class="rpb"><small>Balasan admin · <?= date('d/m/Y H:i', strtotime($m['replied_at'])) ?></small><?= nl2br(e($m['reply'])) ?></div>
                <?php else: ?>
                    <span class="st st1"><i class="sd"></i>Menunggu balasan</span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>

        <?php if (!$msgs): ?>
            <?= empty_state('chat', 'Belum ada pesan', 'Pertanyaan atau masukanmu untuk admin, beserta balasannya, akan muncul di sini.', 'Hubungi Admin', route('contact')) ?>
        <?php endif; ?>
<?php endif; ?>
    </section>
</div>

<?php require ROOT . '/views/footer.php'; ?>