<?php
$title = 'Daftar — Libréa';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $addr  = trim($_POST['address'] ?? '');
    $pass  = $_POST['password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($pass) < 4) {
        $error = 'Isi nama, email yang valid, dan kata sandi minimal 4 karakter.';
    } elseif (val('SELECT 1 FROM users WHERE email=?', [$email])) {
        $error = 'Email sudah terdaftar.';
    } else {
        q('INSERT INTO users (name, email, password, phone, address) VALUES (?,?,?,?,?)',
          [$name, $email, password_hash($pass, PASSWORD_DEFAULT), $phone, $addr]);
        flash('Registrasi berhasil! Silakan masuk');
        go('login');                      // setelah daftar → halaman masuk
    }
}

require ROOT . '/views/header.php';
?>

<div class="box narrow">
    <h2 class="t">Buat Akun</h2>
    <?php if ($error): ?><div class="note"><?= e($error) ?></div><?php endif; ?>

    <form method="post">
        <label>Nama lengkap</label> <input name="name" value="<?= e($_POST['name'] ?? '') ?>" required>
        <label>Email</label>        <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required>
        <label>No. Telepon</label>  <input type="tel" name="phone" placeholder="08xxxxxxxxxx" value="<?= e($_POST['phone'] ?? '') ?>">
        <label>Alamat</label>       <textarea name="address" rows="2" placeholder="Jalan, nomor, kota, kode pos"><?= e($_POST['address'] ?? '') ?></textarea>
        <label>Kata sandi</label>   <input type="password" name="password" required>
        <br><br>
        <button class="btn" style="width:100%">Daftar</button>
    </form>
</div>

<?php require ROOT . '/views/footer.php'; ?>