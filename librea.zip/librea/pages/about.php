<?php
$title = 'About Us — Libréa';
$nBooks = (int)val('SELECT COUNT(*) FROM books');
$nCats  = (int)val('SELECT COUNT(*) FROM categories');

$features = [
    ['book',  'Koleksi Kurasi',             'Setiap judul dipilih dengan hati, dari fiksi hingga sains.'],
    ['check', 'Pembayaran Aman',            'Bayar sebelum buku dikirim, jelas dan transparan.'],
    ['cart',  'Kirim ke Seluruh Indonesia', 'Pesananmu dikemas rapi dan meluncur cepat.'],
    ['chat',  'Admin Responsif',            'Ada pertanyaan? Kirim pesan lewat halaman kontak.'],
];

require ROOT . '/views/header.php';
?>

<section class="ab-hero">
    <span class="eyebrow">✦ TENTANG KAMI</span>
    <h1>Tempat buku bertemu <em>pembacanya</em></h1>
    <p>Libréa lahir dari kecintaan pada buku dan keinginan membuat belanja buku terasa menyenangkan, hangat, dan personal.</p>
</section>

<section class="stats">
    <div class="stat"><b><?= $nBooks ?>+</b><span>Judul Pilihan</span></div>
    <div class="stat"><b><?= $nCats ?></b><span>Kategori</span></div>
    <div class="stat"><b>34</b><span>Provinsi Terjangkau</span></div>
</section>

<section class="story">
    <div class="pic"><?= img_slot('about.jpg') ?></div>
    <div>
        <h2>Cerita Kami</h2>
        <p>Kami percaya sebuah buku bisa mengubah hari, bahkan hidup seseorang. Karena itu Libréa hadir sebagai toko buku online dengan koleksi yang dikurasi agar kamu selalu menemukan bacaan yang tepat.</p>
        <p>Dari novel yang menghangatkan hati sampai buku yang membuka wawasan, kami melayani dengan ramah, cepat, dan transparan.</p>
    </div>
</section>

<h2 class="t" style="text-align:center">Kenapa Libréa?</h2>
<section class="feats">
    <?php foreach ($features as [$ic, $name, $desc]): ?>
        <div class="feat"><i><?= icon($ic) ?></i><h3><?= $name ?></h3><p><?= $desc ?></p></div>
    <?php endforeach; ?>
</section>

<section class="quote">
    <q>Setiap halaman, sebuah dunia baru menantimu.</q>
    <a class="btn" href="<?= route('home') ?>">Mulai Jelajahi Buku</a>
</section>

<?php require ROOT . '/views/footer.php'; ?>