<?php
$title = 'Masuk — Libréa';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = row('SELECT * FROM users WHERE email=?', [strtolower(trim($_POST['email'] ?? ''))]);

    if ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
        $_SESSION['uid'] = $u['id'];
        $u['role'] === 'admin' ? redirect(url('admin/')) : go('home');
    }
    $error = 'Email atau kata sandi salah.';
}

require ROOT . '/views/header.php';
?>

<div class="box narrow">
    <h2 class="t">Selamat Datang</h2>
    <?php if ($error): ?><div class="note"><?= e($error) ?></div><?php endif; ?>

    <form method="post">
        <label>Email</label>      <input type="email" name="email" required>
        <label>Kata sandi</label> <input type="password" name="password" required>
        <br><br>
        <button class="btn" style="width:100%">Masuk</button>
    </form>
</div>

<?php require ROOT . '/views/footer.php'; ?>