<?php
need_login();
$u     = user();
$title = 'Keranjang — Libréa';

$items = rows('SELECT c.qty, b.* FROM cart c JOIN books b ON b.id = c.book_id
               WHERE c.user_id = ? ORDER BY c.id DESC', [$u['id']]);

require ROOT . '/views/header.php';
?>

<?php if (!$items): ?>
    <div class="box narrow" style="text-align:center">
        <h2 class="t">Keranjang kosong</h2>
        <p style="color:var(--mut)">Yuk, temukan buku favoritmu.</p>
        <a class="btn" href="<?= route('home') ?>">Mulai Belanja</a>
    </div>

<?php else: ?>
    <h2 class="t">Keranjang Belanja</h2>

    <div class="chead">
        <input type="checkbox" id="all" checked>
        <label for="all"><b>Pilih Semua</b> <small>(<span id="ccount"><?= count($items) ?></span> produk)</small></label>
    </div>

    <?php foreach ($items as $i): ?>
        <div class="citem">
            <!-- kotak centang terhubung ke form checkout di bawah (form="ck") -->
            <input type="checkbox" name="sel[]" form="ck" value="<?= $i['id'] ?>" data-sub="<?= $i['price'] * $i['qty'] ?>" checked>
            <a class="cvw" href="<?= route('book', ['id' => $i['id']]) ?>"><?= cover($i) ?></a>

            <div class="cinfo">
                <a href="<?= route('book', ['id' => $i['id']]) ?>"><b><?= e($i['title']) ?></b></a>
                <small><?= e($i['author']) ?></small>
                <div class="cpr"><?= rp($i['price']) ?></div>
            </div>

            <div class="cact">
                <!-- jumlah (+ / −): diproses AJAX oleh app.js, halaman tidak berpindah -->
                <form class="qty" method="post" action="<?= action('cart') ?>" data-qty>
                    <input type="hidden" name="op" value="qty">
                    <input type="hidden" name="book_id" value="<?= $i['id'] ?>">
                    <?= back_input() ?>
                    <button type="submit" name="d" value="-1">−</button>
                    <span><?= $i['qty'] ?></span>
                    <button type="submit" name="d" value="1">+</button>
                </form>

                <b class="csub"><?= rp($i['price'] * $i['qty']) ?></b>

                <form method="post" action="<?= action('cart') ?>" data-remove>
                    <input type="hidden" name="op" value="remove">
                    <input type="hidden" name="book_id" value="<?= $i['id'] ?>">
                    <?= back_input() ?>
                    <button class="cdel">Hapus</button>
                </form>
            </div>
        </div>
    <?php endforeach; ?>

    <form id="ck" class="cbar" method="post" action="<?= route('checkout') ?>">
        <span style="color:var(--mut)">Total (<span id="cnt">0</span> produk)</span>
        <div class="cbr">
            <b id="tot">Rp0</b>
            <button class="btn">Checkout</button>
        </div>
    </form>
<?php endif; ?>

<?php require ROOT . '/views/footer.php'; ?>