<?php
require_once ROOT . '/app/payment_config.php';
need_login();
$u     = user();
$title = 'Checkout — Libréa';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') go('cart');

// ---------- 1. Tentukan produk yang dibeli ----------
$isBuy = isset($_POST['buy']);       // "Beli Sekarang" = satu buku saja, tidak lewat keranjang
$sel   = [];

if ($isBuy) {
    $b = row('SELECT * FROM books WHERE id=?', [(int)($_POST['book_id'] ?? 0)]);
    if (!$b || $b['stock'] < 1) { flash('Buku tidak tersedia'); go('home'); }
    $b['qty'] = max(1, min($b['stock'], (int)($_POST['qty'] ?? 1)));
    $items = [$b];
} else {
    $sel = array_values(array_filter(array_map('intval', $_POST['sel'] ?? [])));
    if (!$sel) { flash('Pilih minimal satu produk'); go('cart'); }
    $in    = implode(',', $sel);     // aman: hasil intval
    $items = rows("SELECT c.qty, b.* FROM cart c JOIN books b ON b.id = c.book_id
                   WHERE c.user_id = ? AND b.id IN ($in)", [$u['id']]);
}
if (!$items) go('cart');

$subtotal = 0;
foreach ($items as $i) $subtotal += $i['price'] * $i['qty'];
$total = $subtotal + SHIPPING_FEE;                 // ditambah ongkos kirim

$methods = [
    'bank'    => ['Transfer Bank', 'Pilih bank: BCA, Mandiri, Permata, BRI, BNI'],
    'qris'    => ['QRIS',          'Scan kode QR toko Libréa'],
    'ewallet' => ['E-Wallet',      'GoPay, DANA, atau OVO'],
];

// ---------- 2. Proses "Buat Pesanan" ----------
$error = '';
if (isset($_POST['pay'])) {
    foreach ($items as $i) {
        if ($i['qty'] > $i['stock']) { flash('Stok "' . $i['title'] . '" tersisa ' . $i['stock']); go('cart'); }
    }

    $rcv    = trim($_POST['rcv'] ?? '');
    $phone  = preg_replace('/[\s-]/', '', $_POST['phone'] ?? '');
    $addr   = trim($_POST['addr'] ?? '');
    $method = $_POST['method'] ?? '';

    if ($rcv === '' || !preg_match('/^\+?\d{9,15}$/', $phone) || $addr === '' || !isset($methods[$method])) {
        $error = 'Lengkapi nama penerima, nomor handphone (9–15 angka), alamat, dan metode pembayaran.';
    } else {
        $_SESSION['pending'] = [
            'items'  => array_map(fn($i) => ['id' => $i['id'], 'qty' => $i['qty']], $items),
            'buy'    => $isBuy,
            'rcv'    => $rcv,
            'phone'  => $phone,
            'addr'   => $addr,
            'method' => $method,
        ];
        go('payment');
    }
}

require ROOT . '/views/header.php';
?>

<a class="back" href="<?= $isBuy ? route('book', ['id' => $items[0]['id']]) : route('cart') ?>">← Kembali</a>
<h2 class="t">Checkout</h2>
<?php if ($error): ?><div class="note" style="margin-bottom:16px"><?= e($error) ?></div><?php endif; ?>

<form method="post" class="cols">
    <!-- teruskan pilihan produk -->
    <input type="hidden" name="pay" value="1">
    <?php if ($isBuy): ?>
        <input type="hidden" name="buy" value="1">
        <input type="hidden" name="book_id" value="<?= $items[0]['id'] ?>">
        <input type="hidden" name="qty" value="<?= $items[0]['qty'] ?>">
    <?php else: foreach ($sel as $s): ?>
        <input type="hidden" name="sel[]" value="<?= $s ?>">
    <?php endforeach; endif; ?>

    <div>
        <div class="box csec">
            <h4><?= icon('pin') ?>Alamat Pengiriman</h4>
            <div class="g2">
                <div><label>Nama Penerima</label>
                     <input name="rcv" value="<?= e($_POST['rcv'] ?? $u['name']) ?>" required></div>
                <div><label>No. Handphone</label>
                     <input name="phone" type="tel" placeholder="08xxxxxxxxxx" value="<?= e($_POST['phone'] ?? $u['phone']) ?>" required></div>
            </div>
            <label>Alamat Lengkap</label>
            <textarea name="addr" rows="3" placeholder="Jalan, nomor, kota, kode pos" required><?= e($_POST['addr'] ?? $u['address']) ?></textarea>
        </div>

        <div class="box csec">
            <h4><?= icon('cart') ?>Produk Dipesan</h4>
            <?php foreach ($items as $i): ?>
                <div class="row">
                    <div class="cvw sm"><?= cover($i) ?></div>
                    <div style="flex:1"><b><?= e($i['title']) ?></b><div class="a"><?= rp($i['price']) ?> × <?= $i['qty'] ?></div></div>
                    <b><?= rp($i['price'] * $i['qty']) ?></b>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="box csec">
            <h4>Metode Pembayaran</h4>
            <?php foreach ($methods as $key => [$label, $desc]): ?>
                <label class="pm">
                    <input type="radio" name="method" value="<?= $key ?>" <?= ($_POST['method'] ?? 'bank') === $key ? 'checked' : '' ?>>
                    <span class="pmc">
                        <?= pay_icon($key) ?>
                        <span><b><?= $label ?></b><small><?= $desc ?></small></span>
                    </span>
                </label>
            <?php endforeach; ?>
        </div>
    </div>

    <aside class="box sumb">
        <h4>Rincian Pembayaran</h4>
        <div class="sl"><span>Subtotal produk (<?= count($items) ?>)</span><span><?= rp($subtotal) ?></span></div>
        <div class="sl"><span>Ongkos kirim</span><span><?= rp(SHIPPING_FEE) ?></span></div>
        <div class="sl tl"><span>Total Pembayaran</span><b><?= rp($total) ?></b></div>
        <button class="btn" style="width:100%">Buat Pesanan</button>
        <p class="small">Pembayaran dilakukan sebelum buku dikirim.</p>
    </aside>
</form>

<?php require ROOT . '/views/footer.php'; ?>