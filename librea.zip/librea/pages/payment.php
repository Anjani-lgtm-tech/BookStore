<?php
require_once ROOT . '/app/payment_config.php';
need_login();
$u     = user();
$title = 'Pembayaran — Libréa';

$p = $_SESSION['pending'] ?? null;
if (!$p) go('cart');

// ---------- Data pesanan ----------
$items    = [];
$subtotal = 0;
foreach ($p['items'] as $it) {
    $b = row('SELECT * FROM books WHERE id=?', [$it['id']]);
    if (!$b) continue;
    $b['qty']  = $it['qty'];
    $items[]   = $b;
    $subtotal += $b['price'] * $b['qty'];
}
if (!$items) go('cart');
$total = $subtotal + SHIPPING_FEE;                // ongkir ikut dihitung

$PROVIDERS = [
    'bank'    => ['bca' => 'BCA', 'mandiri' => 'Mandiri', 'permata' => 'Permata', 'bri' => 'BRI', 'bni' => 'BNI'],
    'ewallet' => ['gopay' => 'GoPay', 'dana' => 'DANA', 'ovo' => 'OVO'],
];
$LABEL    = ['bank' => 'Transfer Bank', 'qris' => 'QRIS', 'ewallet' => 'E-Wallet'];
$ACCOUNTS = pay_accounts();

// ---------- Tentukan langkah ----------
$method = $p['method'];
$step   = $_GET['s'] ?? ($method === 'qris' ? 'qris' : 'choose');
$prov   = $_GET['p'] ?? '';

if ($method === 'qris')                            $step = 'qris';
elseif (!in_array($step, ['choose', 'pay'], true)) $step = 'choose';
if ($step === 'pay' && !isset($PROVIDERS[$method][$prov])) $step = 'choose';

$isPost = $_SERVER['REQUEST_METHOD'] === 'POST';

// ---------- Kirim bukti → buat pesanan ----------
if ($isPost && in_array($step, ['pay', 'qris'], true)) {
    $provName = $step === 'qris' ? 'QRIS' : $PROVIDERS[$method][$prov];

    $proof = save_image('proof', 'proofs');
    if (!$proof) {
        flash(image_error() ?: 'Pilih foto bukti pembayaran terlebih dahulu');
        go('payment', ['s' => $step, 'p' => $prov]);
    }

    try {
        $pdo->beginTransaction();

        foreach ($items as $b) {                   // kurangi stok; gagal jika stok tidak cukup
            $ok = q('UPDATE books SET stock = stock - ? WHERE id=? AND stock >= ?', [$b['qty'], $b['id'], $b['qty']])->rowCount();
            if (!$ok) throw new Exception('Stok "' . $b['title'] . '" tidak mencukupi');
        }

        $code = 'ORD-' . strtoupper(substr(uniqid(), -7));
        q('INSERT INTO orders (order_code, user_id, receiver_name, receiver_phone, address, total, method, provider, account_mask, proof, status, paid_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?, NOW())',
          [$code, $u['id'], $p['rcv'], $p['phone'], $p['addr'], $total, $LABEL[$method], $provName, '', $proof, 'Dibayar']);
        $orderId = $pdo->lastInsertId();

        foreach ($items as $b) {
            q('INSERT INTO order_items (order_id, book_id, title, price, qty) VALUES (?,?,?,?,?)',
              [$orderId, $b['id'], $b['title'], $b['price'], $b['qty']]);
            if (!$p['buy']) q('DELETE FROM cart WHERE user_id=? AND book_id=?', [$u['id'], $b['id']]);
        }

        $pdo->commit();
        unset($_SESSION['pending']);
        go('success', ['code' => $code]);
    } catch (Exception $ex) {
        $pdo->rollBack();
        flash($ex->getMessage());
        go('cart');
    }
}

// ==========================================================================
// Potongan tampilan yang dipakai ulang
// ==========================================================================

// Penanda alur: Checkout (selesai) → Pembayaran (sekarang) → Selesai
function pay_flow() {
    return '<div class="pay-flow">'
         .   '<div class="pf done"><i>' . icon('check') . '</i><span>Checkout</span></div>'
         .   '<div class="pf-line done"></div>'
         .   '<div class="pf on"><i>2</i><span>Pembayaran</span></div>'
         .   '<div class="pf-line"></div>'
         .   '<div class="pf"><i>3</i><span>Selesai</span></div>'
         . '</div>';
}

// Tombol kembali ke checkout (semua isian tetap terisi, tinggal pilih metode lain)
function back_to_checkout($p, $label = 'Ganti metode pembayaran') {
    $f = '<form method="post" action="' . route('checkout') . '">';
    if ($p['buy']) {
        $f .= '<input type="hidden" name="buy" value="1">'
            . '<input type="hidden" name="book_id" value="' . (int)$p['items'][0]['id'] . '">'
            . '<input type="hidden" name="qty" value="' . (int)$p['items'][0]['qty'] . '">';
    } else {
        foreach ($p['items'] as $it) $f .= '<input type="hidden" name="sel[]" value="' . (int)$it['id'] . '">';
    }
    foreach (['rcv', 'phone', 'addr', 'method'] as $k) {
        $f .= '<input type="hidden" name="' . $k . '" value="' . e($p[$k]) . '">';
    }
    return $f . '<button class="btn o s">← ' . e($label) . '</button></form>';
}

// Kartu nominal bergaya struk: total besar + rincian (subtotal, ongkir)
function pay_amount_box($subtotal, $total) {
    return '<div class="amt">'
         .   '<div class="amt-main">'
         .     '<div><small>Total yang harus dibayar</small><b>' . rp($total) . '</b></div>'
         .     '<button type="button" class="copy" data-copy="' . (int)$total . '">Salin nominal</button>'
         .   '</div>'
         .   '<div class="amt-cut"></div>'
         .   '<div class="amt-rows">'
         .     '<div><span>Subtotal produk</span><span>' . rp($subtotal) . '</span></div>'
         .     '<div><span>Ongkos kirim</span><span>' . rp(SHIPPING_FEE) . '</span></div>'
         .     '<div class="t"><span>Total</span><span>' . rp($total) . '</span></div>'
         .   '</div>'
         . '</div>'
         . '<span class="pay-tip">' . icon('check') . 'Bayar tepat sesuai nominal agar cepat dikonfirmasi</span>';
}

// Tiga langkah singkat
function pay_how($a, $b, $c) {
    return '<div class="how">'
         .   '<div><i>1</i>' . $a . '</div>'
         .   '<div><i>2</i>' . $b . '</div>'
         .   '<div><i>3</i>' . $c . '</div>'
         . '</div>';
}

// Kartu langkah 2: unggah bukti
function pay_upload_card() {
    return '<div class="pay-card">'
         .   '<div class="pay-head"><i>2</i><div><h3>Unggah bukti pembayaran</h3><small>Foto atau screenshot bukti transfer</small></div></div>'
         .   '<form method="post" enctype="multipart/form-data">'
         .     '<label class="drop" for="proof" id="pv">' . icon('upload')
         .       '<b>Ketuk untuk memilih foto bukti</b><span>JPG, PNG, WEBP, GIF, dan format lain · maks. 20 MB</span></label>'
         .     '<input type="file" id="proof" name="proof" accept="image/*" data-preview="pv" hidden>'
         .     '<br><button class="btn" style="width:100%">Kirim Bukti Pembayaran</button>'
         .   '</form>'
         . '</div>';
}

require ROOT . '/views/header.php';
?>

<link rel="stylesheet" href="<?= url('assets/css/payment.css') ?>?v=<?= (int)@filemtime(ROOT . '/assets/css/payment.css') ?>">

<div class="pay-wrap">

<?php /* ================= LANGKAH: PILIH BANK / E-WALLET ================= */ if ($step === 'choose'): ?>

    <div class="pay-top"><?= back_to_checkout($p) ?></div>
    <?= pay_flow() ?>

    <h2 class="t">Pembayaran <?= $LABEL[$method] ?></h2>
    <p class="sub">Total yang harus dibayar: <b><?= rp($total) ?></b> <small>(sudah termasuk ongkir <?= rp(SHIPPING_FEE) ?>)</small></p>

    <h4>Pilih <?= $method === 'bank' ? 'bank' : 'e-wallet' ?> tujuan</h4>
    <?php foreach ($PROVIDERS[$method] as $key => $name): ?>
        <a class="pm" href="<?= route('payment', ['s' => 'pay', 'p' => $key]) ?>">
            <span class="pmc"><?= prov_tile($key, $name) ?><span><b><?= $name ?></b></span></span>
        </a>
    <?php endforeach; ?>


<?php /* ================= LANGKAH: BANK / E-WALLET ================= */ elseif ($step === 'pay'):
    $name   = $PROVIDERS[$method][$prov];
    $acc    = $ACCOUNTS[$method][$prov] ?? ['no' => '-', 'an' => '-'];
    $isBank = $method === 'bank';
    $noShow = trim(chunk_split(preg_replace('/\s+/', '', $acc['no']), 4, ' '));   // 1234 5678 90
?>

    <div class="pay-top">
        <a class="btn o s" href="<?= route('payment', ['s' => 'choose']) ?>">← Pilih <?= $isBank ? 'bank' : 'e-wallet' ?> lain</a>
        <?= back_to_checkout($p) ?>
    </div>
    <?= pay_flow() ?>

    <div class="pay-card">
        <div class="pay-head">
            <i>1</i>
            <div>
                <h3><?= $isBank ? 'Transfer ke rekening berikut' : 'Kirim ke nomor berikut' ?></h3>
                <small><?= $isBank ? 'Bisa dari bank mana saja' : 'Lewat aplikasi ' . e($name) ?></small>
            </div>
        </div>

        <!-- kartu rekening -->
        <div class="bank-card">
            <div class="bc-top">
                <div class="bc-prov">
                    <?= prov_tile($prov, $name) ?>
                    <div><b><?= e($name) ?></b><small><?= $isBank ? 'Rekening tujuan' : 'E-wallet tujuan' ?></small></div>
                </div>
                <span class="bc-chip"></span>
            </div>

            <div class="bc-label"><?= $isBank ? 'Nomor rekening' : 'Nomor ' . e($name) ?></div>
            <div class="bc-no"><?= e($noShow) ?></div>

            <div class="bc-bot">
                <div><small>Atas nama</small><b><?= e($acc['an']) ?></b></div>
                <button type="button" class="copy" data-copy="<?= e($acc['no']) ?>">Salin nomor</button>
            </div>
        </div>

        <?= pay_amount_box($subtotal, $total) ?>

        <?= pay_how(
            ($isBank ? 'Transfer' : 'Kirim') . ' ke nomor di atas, <b>tepat sesuai nominal</b>.',
            'Simpan <b>bukti</b> berupa screenshot atau foto struk.',
            '<b>Unggah bukti</b> di kartu langkah 2 di bawah.'
        ) ?>
    </div>

    <?= pay_upload_card() ?>


<?php /* ================= LANGKAH: QRIS ================= */ else:
    $qrFile = find_img('qris');
?>

    <div class="pay-top"><?= back_to_checkout($p) ?></div>
    <?= pay_flow() ?>

    <div class="pay-card">
        <div class="pay-head">
            <i>1</i>
            <div><h3>Scan kode QRIS</h3><small>Bisa dibayar dari semua aplikasi bank dan e-wallet</small></div>
        </div>

        <?php if ($qrFile): ?>
            <div class="pay-qr"><img src="<?= url($qrFile) ?>?v=<?= filemtime(ROOT . '/' . $qrFile) ?>" alt="QRIS Libréa"></div>
        <?php else: ?>
            <div class="pay-qr none">Gambar QRIS<br>belum ditambahkan</div>
        <?php endif; ?>

        <?= pay_amount_box($subtotal, $total) ?>

        <?= pay_how(
            '<b>Scan</b> kode QRIS di atas dengan aplikasi pembayaranmu.',
            'Masukkan <b>nominal tepat</b> seperti di atas lalu bayar.',
            'Simpan bukti, lalu <b>unggah</b> di kartu langkah 2 di bawah.'
        ) ?>
    </div>

    <?= pay_upload_card() ?>

<?php endif; ?>

</div>

<script>
// tombol "Salin" (nomor rekening / nominal)
document.querySelectorAll('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', async function () {
        var text = btn.dataset.copy;
        try {
            await navigator.clipboard.writeText(text);
        } catch (e) {                                   // cadangan untuk browser lama
            var tmp = document.createElement('input');
            tmp.value = text;
            document.body.appendChild(tmp);
            tmp.select();
            document.execCommand('copy');
            tmp.remove();
        }
        var old = btn.textContent;
        btn.textContent = 'Tersalin ✓';
        setTimeout(function () { btn.textContent = old; }, 1800);
    });
});
</script>

<?php require ROOT . '/views/footer.php'; ?>