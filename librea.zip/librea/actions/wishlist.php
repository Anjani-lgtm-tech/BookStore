<?php
need_login();
$u   = user();
$bid = (int)($_POST['book_id'] ?? 0);

if (val('SELECT 1 FROM wishlist WHERE user_id=? AND book_id=?', [$u['id'], $bid])) {
    q('DELETE FROM wishlist WHERE user_id=? AND book_id=?', [$u['id'], $bid]);       // sudah ada → hapus
} elseif (val('SELECT 1 FROM books WHERE id=?', [$bid])) {
    q('INSERT INTO wishlist (user_id, book_id) VALUES (?,?)', [$u['id'], $bid]);      // belum ada → tambah
}

go_back('home');