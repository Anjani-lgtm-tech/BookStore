<?php
session_destroy();
go('home');