<?php
// Dipanggil lewat index.php?do=cart
// Mode AJAX (header X-Requested-With: fetch) → jawaban JSON, halaman tidak berpindah/reload.
$ajax = ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'fetch';

function cart_json($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!user()) {
    if ($ajax) cart_json(['ok' => false, 'msg' => 'Silakan masuk terlebih dahulu', 'login' => route('login')]);
    need_login();
}

$u      = user();
$op     = $_POST['op'] ?? '';
$bid    = (int)($_POST['book_id'] ?? 0);
$b      = row('SELECT * FROM books WHERE id=?', [$bid]);
$result = [];                                    // data tambahan untuk balasan AJAX

if ($b) {
    $have = (int)val('SELECT qty FROM cart WHERE user_id=? AND book_id=?', [$u['id'], $bid]);

    // Tambah ke keranjang (dibatasi sisa stok)
    if ($op === 'add') {
        $n = min(max(1, (int)($_POST['qty'] ?? 1)), $b['stock'] - $have);
        if ($n <= 0) {
            flash('Stok tidak mencukupi');
        } else {
            q('INSERT INTO cart (user_id, book_id, qty) VALUES (?,?,?)
               ON DUPLICATE KEY UPDATE qty = qty + VALUES(qty)', [$u['id'], $bid, $n]);
            flash('Pesananmu sudah ada di keranjang ✓');
        }
    }

    // Ubah jumlah (+1 / -1)
    if ($op === 'qty' && $have) {
        $d   = (int)($_POST['d'] ?? 0);
        $new = max(1, min($b['stock'], $have + $d));
        if ($d > 0 && $new === $have) flash('Stok hanya ' . $b['stock']);
        q('UPDATE cart SET qty=? WHERE user_id=? AND book_id=?', [$new, $u['id'], $bid]);
        $result = ['qty' => $new, 'sub' => $new * (int)$b['price']];
    }

    // Hapus dari keranjang
    if ($op === 'remove') {
        q('DELETE FROM cart WHERE user_id=? AND book_id=?', [$u['id'], $bid]);
        $result = ['removed' => true];
    }
}

// AJAX: balas JSON (pesan + jumlah isi keranjang untuk badge + data baris)
if ($ajax) {
    $count = (int)val('SELECT COALESCE(SUM(qty),0) FROM cart WHERE user_id=?', [$u['id']]);
    cart_json(['ok' => true, 'msg' => flash(), 'count' => $count] + $result);
}

go_back('cart');