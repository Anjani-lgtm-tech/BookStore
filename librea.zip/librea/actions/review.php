<?php
need_login();
$u      = user();
$oid    = (int)($_POST['order_id'] ?? 0);
$bid    = (int)($_POST['book_id'] ?? 0);
$rating = (int)($_POST['rating'] ?? 0);

// hanya boleh mengulas buku dari pesanan miliknya yang sudah Selesai
$valid = val("SELECT 1 FROM orders o JOIN order_items oi ON oi.order_id = o.id
              WHERE o.id=? AND o.user_id=? AND o.status='Selesai' AND oi.book_id=?", [$oid, $u['id'], $bid]);

if ($valid && $rating >= 1 && $rating <= 5) {
    q('INSERT IGNORE INTO reviews (user_id, book_id, order_id, rating, comment) VALUES (?,?,?,?,?)',
      [$u['id'], $bid, $oid, $rating, trim($_POST['comment'] ?? '')]);
    flash('Terima kasih atas ulasanmu ✓');
} else {
    flash('Ulasan tidak dapat disimpan');
}

go('profile', ['tab' => 'pesanan']);