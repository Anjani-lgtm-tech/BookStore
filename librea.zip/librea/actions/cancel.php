<?php
// Proses sisi user: batalkan pesanan · isi tujuan pengembalian · konfirmasi dana diterima
need_login();
$u  = user();
$op = $_POST['op'] ?? '';
$o  = row('SELECT * FROM orders WHERE id=? AND user_id=?', [(int)($_POST['order_id'] ?? 0), $u['id']]);

if (!$o) {
    flash('Pesanan tidak ditemukan');
    go('profile', ['tab' => 'pesanan']);
}

// ---------- 1. Batalkan pesanan ----------
if ($op === 'cancel') {
    $reason = $_POST['reason'] ?? '';
    $note   = trim($_POST['note'] ?? '');

    if (!can_user_cancel($o)) {
        flash('Pesanan sudah diproses, tidak dapat dibatalkan');
    } elseif (!in_array($reason, cancel_reasons('user'), true)) {
        flash('Pilih alasan pembatalan');
    } elseif ($reason === 'Lainnya' && $note === '') {
        flash('Tulis alasanmu pada kolom catatan');
    } else {
        [$acc, $err] = parse_refund_post();
        if (!$acc) {
            flash($err);
        } elseif (cancel_order($o, 'user', $reason, mb_substr($note, 0, 500), $acc)) {
            flash('Pesanan dibatalkan. Admin akan mengembalikan dana ke tujuan yang kamu isi.');
        } else {
            flash('Pembatalan gagal, silakan coba lagi');
        }
    }
}

// ---------- 2. Isi tujuan pengembalian (untuk pesanan yang dibatalkan admin) ----------
elseif ($op === 'account') {
    [$acc, $err] = parse_refund_post();

    if ($o['status'] !== 'Dibatalkan' || $o['refund_status'] !== 'Menunggu Data Rekening') {
        flash('Data pengembalian dana tidak dapat diubah');
    } elseif (!$acc) {
        flash($err);
    } else {
        q("UPDATE orders SET refund_status='Menunggu Pengembalian Dana', refund_method=?, refund_account=?, refund_name=? WHERE id=?",
          [$acc['method'], $acc['account'], $acc['name'], $o['id']]);
        flash('Data pengembalian dana terkirim ✓');
    }
}

// ---------- 3. Konfirmasi dana diterima (wajib unggah foto bukti) ----------
elseif ($op === 'confirm') {
    if ($o['status'] !== 'Dibatalkan' || $o['refund_status'] !== 'Dana Dikembalikan') {
        flash('Konfirmasi tidak dapat dilakukan');
    } else {
        $img = save_image('proof', 'refunds');
        if (!$img) {
            flash(image_error() ?: 'Unggah foto bukti bahwa dana sudah kamu terima');
        } else {
            q("UPDATE orders SET refund_status='Selesai', refund_confirm_proof=?, refund_confirmed_at=NOW() WHERE id=?", [$img, $o['id']]);
            flash('Terima kasih, pengembalian dana selesai ✓');
        }
    }
}

go('profile', ['tab' => 'pesanan']);